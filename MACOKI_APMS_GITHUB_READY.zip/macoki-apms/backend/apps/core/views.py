from django.http import JsonResponse
from django.utils import timezone
from rest_framework import viewsets,permissions,status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import User,Patient,Visit,FollowUp,SyncOperation,AuditLog
from .serializers import UserSerializer,PatientSerializer,VisitSerializer,FollowUpSerializer,SyncSerializer

def health(request): return JsonResponse({'status':'ok','service':'MACOKI APMS','date':timezone.now().isoformat()})
class MeView(APIView):
 permission_classes=[permissions.IsAuthenticated]
 def get(self,request):return Response(UserSerializer(request.user).data)
class PatientViewSet(viewsets.ModelViewSet):
 queryset=Patient.objects.filter(is_active=True).order_by('-created_at');serializer_class=PatientSerializer
 def get_queryset(self):
  qs=super().get_queryset();q=self.request.query_params.get('q');return qs.filter(first_name__icontains=q)|qs.filter(last_name__icontains=q) if q else qs
 def perform_create(self,s):
  from datetime import date
  n=Patient.objects.count()+1;s.save(patient_id=f'MAC-PAT-{n:06d}',registration_date=s.validated_data.get('registration_date') or date.today(),created_by=self.request.user if self.request.user.is_authenticated else None)
class VisitViewSet(viewsets.ModelViewSet):
 queryset=Visit.objects.all().order_by('-visit_date','-created_at');serializer_class=VisitSerializer
 def perform_create(self,s):
  from datetime import date
  n=Visit.objects.count()+1;s.save(visit_id=f'VIS-{date.today():%Y%m%d}-{n:03d}',healthcare_worker=self.request.user if self.request.user.is_authenticated else None)
class FollowUpViewSet(viewsets.ModelViewSet):
 queryset=FollowUp.objects.select_related('patient').all().order_by('followup_date');serializer_class=FollowUpSerializer
 def perform_create(self,s):
  from datetime import date
  n=FollowUp.objects.count()+1;s.save(followup_id=f'FUP-{date.today():%Y%m%d}-{n:03d}',created_by=self.request.user if self.request.user.is_authenticated else None)
class SyncViewSet(viewsets.ModelViewSet):
 queryset=SyncOperation.objects.all().order_by('-created_at');serializer_class=SyncSerializer
