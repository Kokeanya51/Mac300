from rest_framework import serializers
from django.contrib.auth.models import User
from .models import StaffProfile,Patient,Visit,VitalSigns,FollowUp,SyncOperation
class UserSerializer(serializers.ModelSerializer):
 role=serializers.SerializerMethodField();phone=serializers.SerializerMethodField()
 class Meta:model=User;fields=['id','username','email','first_name','last_name','phone','role']
 def get_role(self,obj): return getattr(getattr(obj,'profile',None),'role',None)
 def get_phone(self,obj): return getattr(getattr(obj,'profile',None),'phone','')
class PatientSerializer(serializers.ModelSerializer):
 class Meta:model=Patient;fields='__all__';read_only_fields=['id','patient_id','created_by','created_at','updated_at','last_visit_date']
class VitalSerializer(serializers.ModelSerializer):
 class Meta:model=VitalSigns;fields='__all__';read_only_fields=['id','measured_at','recorded_by']
class VisitSerializer(serializers.ModelSerializer):
 vitals=VitalSerializer(read_only=True)
 class Meta:model=Visit;fields='__all__';read_only_fields=['id','visit_id','healthcare_worker','created_at','updated_at']
class FollowUpSerializer(serializers.ModelSerializer):
 patient_name=serializers.SerializerMethodField()
 class Meta:model=FollowUp;fields='__all__';read_only_fields=['id','followup_id','created_by','created_at','updated_at']
 def get_patient_name(self,obj):return f'{obj.patient.first_name} {obj.patient.last_name}'
class SyncSerializer(serializers.ModelSerializer):
 class Meta:model=SyncOperation;fields='__all__'
