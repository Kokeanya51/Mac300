from django.contrib import admin
from django.contrib.auth.models import User
from .models import StaffProfile,Patient,Visit,VitalSigns,FollowUp,SyncOperation,AuditLog
for m in [StaffProfile,Patient,Visit,VitalSigns,FollowUp,SyncOperation,AuditLog]: admin.site.register(m)
