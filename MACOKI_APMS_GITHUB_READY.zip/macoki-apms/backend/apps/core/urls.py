from rest_framework.routers import DefaultRouter
from .views import PatientViewSet,VisitViewSet,FollowUpViewSet,SyncViewSet
r=DefaultRouter();r.register('patients',PatientViewSet);r.register('visits',VisitViewSet);r.register('followups',FollowUpViewSet);r.register('sync',SyncViewSet)
urlpatterns=r.urls
