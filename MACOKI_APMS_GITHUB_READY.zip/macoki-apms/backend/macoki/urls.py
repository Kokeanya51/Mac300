from django.contrib import admin
from django.urls import path,include
from rest_framework_simplejwt.views import TokenObtainPairView,TokenRefreshView
from apps.core.views import health,MeView
urlpatterns=[path('admin/',admin.site.urls),path('api/v1/health/',health),path('api/v1/auth/token/',TokenObtainPairView.as_view()),path('api/v1/auth/token/refresh/',TokenRefreshView.as_view()),path('api/v1/auth/me/',MeView.as_view()),path('api/v1/',include('apps.core.urls'))]
