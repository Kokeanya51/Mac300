# MACOKI APMS

MACOKI Patient Management System (APMS) is an offline-first clinic web application based on the supplied MACOKI implementation documents.

## Included working layers
- Frontend: React + Vite, HTML/CSS/JavaScript, responsive dashboard, patient registration/search, visit UI and follow-up UI.
- Local data: IndexedDB queue for offline patient records.
- Backend: Django REST API with JWT-ready authentication endpoints, patient/visit/follow-up/sync resources and admin.
- Data storage: PostgreSQL 18 through Docker Compose.
- Infrastructure: Docker and Redis development service.

The supplied architecture specifies React PWA → IndexedDB → Sync Engine → Django REST API → PostgreSQL, with JWT authentication and offline synchronization. See the supplied implementation summary and database schema for the original design. 

## Run locally with Docker
```bash
docker compose up --build
```
Open:
- Frontend: http://localhost:5173
- Backend health: http://localhost:8000/api/v1/health/
- Admin: http://localhost:8000/admin/

## Create an admin user
```bash
docker compose exec backend python manage.py createsuperuser
```

## Important
This is an implementation starter/MVP, not a production clinical deployment. Before handling real patient data, configure strong secrets, HTTPS, access controls, backups, audit review, privacy/compliance controls and security testing.
