# MACOKI APMS — GitHub Repository Template

This document contains all files needed to initialize the MACOKI APMS GitHub repository. Copy and paste into their respective locations.

---

## 1. REPOSITORY INITIALIZATION SCRIPT

Save as: `setup-repo.sh`

```bash
#!/bin/bash
# MACOKI APMS Repository Setup Script
# Run this script to initialize the repository structure

set -e

echo "🚀 Setting up MACOKI APMS Repository..."

# Create directory structure
mkdir -p frontend/src/{components,pages,hooks,stores,services,db,sync,routes,types,schemas,utils,config,workers}
mkdir -p frontend/src/components/{common,layout,auth,patients,visits,vitals,followups,dashboard}
mkdir -p frontend/src/pages/{auth,dashboard,patients,visits,followups,users,audit,errors}
mkdir -p frontend/public/{icons}
mkdir -p frontend/tests/{components,pages,services,sync}

mkdir -p backend/config/{settings}
mkdir -p backend/apps/{accounts,patients,visits,followups,synchronization,audit,dashboard}
mkdir -p backend/common/{permissions,middleware,exceptions,pagination,validators,utilities}
mkdir -p backend/tests

mkdir -p docker/{frontend,backend,nginx}
mkdir -p docs/{architecture,api,security,deployment,operations,user-guides}
mkdir -p scripts
mkdir -p .github/workflows

echo "✅ Directory structure created"

# Create .gitignore
cat > .gitignore << 'EOF'
# Dependencies
node_modules/
venv/
env/
.venv/
*.egg-info/
dist/
build/

# Environment
.env
.env.local
.env.*.local

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.DS_Store

# Build output
dist/
build/
*.pyc
__pycache__/
.pytest_cache/
.coverage
htmlcov/

# Logs
*.log
logs/

# OS
.DS_Store
Thumbs.db

# Testing
.vitest/
.pytest_cache/

# Python
*.egg
*.egg-info
.Python

# Django
db.sqlite3
/static/
/media/
EOF

echo "✅ .gitignore created"

# Create .dockerignore
cat > .dockerignore << 'EOF'
node_modules
venv
.git
.gitignore
*.log
.env
.DS_Store
.vscode
.idea
Makefile
docker-compose.yml
.pytest_cache
.vitest
EOF

echo "✅ .dockerignore created"

# Create README.md
cat > README.md << 'EOF'
# MACOKI APMS — Patient Management System

A comprehensive, offline-first healthcare patient management system built for Nigerian clinics.

## Features

- ✅ Patient Registration & Search
- ✅ Clinical Visit Recording
- ✅ Vital Signs Tracking
- ✅ Follow-up Management
- ✅ Offline-First Architecture (works without internet)
- ✅ Synchronization with Cloud
- ✅ Role-Based Access Control
- ✅ Audit Logging

## Tech Stack

**Frontend:** React 19.3 + TypeScript + Vite + Tailwind CSS + Zustand + IndexedDB  
**Backend:** Django 5.2 LTS + Django REST Framework + PostgreSQL  
**DevOps:** Docker + GitHub Actions + Vercel + Render  

## Quick Start

### With Docker (Recommended)

```bash
docker-compose up -d
# Frontend: http://localhost:5173
# Backend: http://localhost:8000
# Admin: http://localhost:8000/admin
```

### Manual Setup

See [DEVELOPMENT.md](DEVELOPMENT.md) for detailed setup instructions.

## Project Structure

```
macoki-apms/
├── frontend/          # React + Vite application
├── backend/           # Django REST API
├── docs/              # Architecture & technical docs
├── docker/            # Docker configurations
├── scripts/           # Utility scripts
└── .github/           # GitHub Actions workflows
```

## Documentation

- [Architecture Overview](docs/architecture/system-architecture.md)
- [Database Schema](docs/architecture/database-schema.md)
- [API Endpoints](docs/api/openapi.yaml)
- [Development Guide](DEVELOPMENT.md)
- [Deployment Guide](docs/deployment/production.md)

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md)

## License

MIT License — See LICENSE file

## Support

For issues and questions, open a GitHub issue.

---

**Built with ❤️ for healthcare in Nigeria**
EOF

echo "✅ README.md created"

# Create DEVELOPMENT.md
cat > DEVELOPMENT.md << 'EOF'
# Development Setup Guide

Get MACOKI APMS running locally in <30 minutes.

## Prerequisites

- Docker & Docker Compose (recommended)
- OR Node.js 20 + Python 3.13 + PostgreSQL 18

## Option 1: Docker (Quickest)

```bash
# Start all services
docker-compose up -d

# Services available at:
# - Frontend: http://localhost:5173
# - Backend API: http://localhost:8000
# - Admin: http://localhost:8000/admin
# - PostgreSQL: localhost:5432

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Stop services
docker-compose down
```

## Option 2: Manual Setup

### Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Initialize database
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Start server
python manage.py runserver
```

Backend runs at: http://localhost:8000

### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env with API base URL

# Start dev server
npm run dev
```

Frontend runs at: http://localhost:5173

## Verification

```bash
# Frontend responsive
curl http://localhost:5173

# Backend responding
curl http://localhost:8000/api/v1/health/

# Database connected
curl http://localhost:8000/admin  # Should load login page
```

## Testing

### Backend Tests

```bash
cd backend
pytest
pytest --cov=apps  # With coverage
```

### Frontend Tests

```bash
cd frontend
npm run test
npm run test:coverage
```

## Troubleshooting

### Port Already in Use

```bash
# Find process using port
lsof -i :5173  # Frontend
lsof -i :8000  # Backend
lsof -i :5432  # PostgreSQL

# Kill process
kill -9 <PID>
```

### Database Connection Failed

Ensure PostgreSQL is running and .env has correct DATABASE_URL

### Docker Compose Issues

```bash
# View container logs
docker-compose logs

# Rebuild containers
docker-compose down -v
docker-compose up -d --build
```

## Common Tasks

### Create Database Backup

```bash
docker exec macoki-apms-postgres pg_dump -U macoki_user macoki_apms > backup.sql
```

### Restore Database

```bash
docker exec -i macoki-apms-postgres psql -U macoki_user macoki_apms < backup.sql
```

### Clear Cache & Restart

```bash
docker-compose down
docker-compose up -d --build
```

### Run Django Migrations

```bash
docker-compose exec backend python manage.py migrate
```

## Need Help?

Open an issue on GitHub or check project documentation.
EOF

echo "✅ DEVELOPMENT.md created"

# Create CONTRIBUTING.md
cat > CONTRIBUTING.md << 'EOF'
# Contributing to MACOKI APMS

Thank you for contributing! Please follow these guidelines.

## Getting Started

1. Fork the repository
2. Clone your fork
3. Create a feature branch: `git checkout -b feature/my-feature`
4. See [DEVELOPMENT.md](DEVELOPMENT.md) for local setup

## Workflow

1. Make your changes
2. Write/update tests
3. Ensure tests pass: `pytest`, `npm run test`
4. Commit with clear message: `git commit -m "feat: add patient search"`
5. Push to your fork
6. Create Pull Request

## Code Standards

- Use descriptive commit messages
- Write tests for new features (target >80% coverage)
- Follow existing code style
- Update documentation as needed

## Commit Message Format

```
feat: add new feature
fix: fix a bug
docs: update documentation
test: add tests
refactor: refactor code
chore: update dependencies
```

## Pull Request Process

1. Update README.md if needed
2. Request review from maintainers
3. Address feedback
4. Merge when approved

## Questions?

Open an issue or discussion on GitHub.
EOF

echo "✅ CONTRIBUTING.md created"

# Create LICENSE
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2024 MACOKI APMS Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF

echo "✅ LICENSE created"

echo ""
echo "✅ Repository setup complete!"
echo ""
echo "Next steps:"
echo "1. cd macoki-apms"
echo "2. git init"
echo "3. git add ."
echo "4. git commit -m 'initial: project foundation'"
echo "5. git remote add origin https://github.com/your-org/macoki-apms.git"
echo "6. git push -u origin main"
```

---

## 2. DOCKER COMPOSE FILE

Save as: `docker-compose.yml`

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:18
    container_name: macoki-apms-postgres
    environment:
      POSTGRES_DB: macoki_apms
      POSTGRES_USER: macoki_user
      POSTGRES_PASSWORD: macoki_password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U macoki_user"]
      interval: 10s
      timeout: 5s
      retries: 5

  backend:
    build:
      context: .
      dockerfile: docker/backend/Dockerfile
    container_name: macoki-apms-backend
    command: >
      sh -c "python manage.py migrate &&
             python manage.py runserver 0.0.0.0:8000"
    ports:
      - "8000:8000"
    volumes:
      - ./backend:/app
    environment:
      - DATABASE_URL=postgresql://macoki_user:macoki_password@postgres:5432/macoki_apms
      - DJANGO_SECRET_KEY=dev-secret-key-change-in-production
      - DJANGO_DEBUG=True
      - ALLOWED_HOSTS=localhost,127.0.0.1,backend
      - CORS_ALLOWED_ORIGINS=http://localhost:5173
    depends_on:
      postgres:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/api/v1/health/"]
      interval: 10s
      timeout: 5s
      retries: 5

  frontend:
    build:
      context: ./frontend
      dockerfile: ../docker/frontend/Dockerfile
    container_name: macoki-apms-frontend
    ports:
      - "5173:5173"
    volumes:
      - ./frontend:/app
      - /app/node_modules
    environment:
      - VITE_API_BASE_URL=http://localhost:8000/api/v1
      - VITE_APP_NAME=MACOKI APMS
    command: npm run dev

volumes:
  postgres_data:

networks:
  default:
    name: macoki-apms-network
```

---

## 3. DOCKER FILES

### Save as: `docker/frontend/Dockerfile`

```dockerfile
FROM node:20-alpine as builder

WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM node:20-alpine

WORKDIR /app

RUN npm install -g serve

COPY --from=builder /app/dist ./dist

EXPOSE 5173

CMD ["serve", "-s", "dist", "-l", "5173"]
```

### Save as: `docker/backend/Dockerfile`

```dockerfile
FROM python:3.13-slim as builder

WORKDIR /app

COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

FROM python:3.13-slim

WORKDIR /app

COPY --from=builder /root/.local /root/.local
ENV PATH=/root/.local/bin:$PATH

COPY . .

EXPOSE 8000

CMD ["gunicorn", "config.wsgi:application", "--bind", "0.0.0.0:8000", "--workers", "4"]
```

### Save as: `docker/nginx/nginx.conf` (Optional, for production)

```nginx
upstream backend {
    server backend:8000;
}

upstream frontend {
    server frontend:5173;
}

server {
    listen 80;
    server_name localhost;

    client_max_body_size 10M;

    location /api/ {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location / {
        proxy_pass http://frontend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

---

## 4. GITHUB ACTIONS WORKFLOWS

### Save as: `.github/workflows/frontend-ci.yml`

```yaml
name: Frontend CI

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'frontend/**'
      - '.github/workflows/frontend-ci.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'frontend/**'

jobs:
  test:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - uses: actions/checkout@v3
    
    - name: Use Node.js ${{ matrix.node-version }}
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}
        cache: 'npm'
        cache-dependency-path: frontend/package-lock.json

    - name: Install dependencies
      run: cd frontend && npm ci

    - name: Run linting
      run: cd frontend && npm run lint

    - name: Run tests
      run: cd frontend && npm run test

    - name: Run build
      run: cd frontend && npm run build

    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        files: ./frontend/coverage/coverage-final.json
        flags: frontend
```

### Save as: `.github/workflows/backend-ci.yml`

```yaml
name: Backend CI

on:
  push:
    branches: [ main, develop ]
    paths:
      - 'backend/**'
      - '.github/workflows/backend-ci.yml'
  pull_request:
    branches: [ main, develop ]
    paths:
      - 'backend/**'

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:18
        env:
          POSTGRES_DB: test_macoki_apms
          POSTGRES_USER: test_user
          POSTGRES_PASSWORD: test_password
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    strategy:
      matrix:
        python-version: ['3.13']

    steps:
    - uses: actions/checkout@v3

    - name: Set up Python ${{ matrix.python-version }}
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}
        cache: 'pip'

    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        cd backend && pip install -r requirements-dev.txt

    - name: Run linting
      run: cd backend && pylint apps common || true

    - name: Run tests
      run: cd backend && pytest --cov=apps
      env:
        DATABASE_URL: postgresql://test_user:test_password@localhost:5432/test_macoki_apms

    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        files: ./backend/.coverage
        flags: backend
```

### Save as: `.github/workflows/security-scan.yml`

```yaml
name: Security Scan

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]
  schedule:
    - cron: '0 0 * * 0'  # Weekly

jobs:
  dependabot:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Run Dependabot
      uses: dependabot/fetch-metadata@v1

  codeql:
    runs-on: ubuntu-latest
    
    strategy:
      matrix:
        language: [ 'python', 'javascript' ]

    steps:
    - uses: actions/checkout@v3

    - name: Initialize CodeQL
      uses: github/codeql-action/init@v2
      with:
        languages: ${{ matrix.language }}

    - name: Autobuild
      uses: github/codeql-action/autobuild@v2

    - name: Perform CodeQL Analysis
      uses: github/codeql-action/analyze@v2
```

---

## 5. ENVIRONMENT TEMPLATES

### Save as: `frontend/.env.example`

```
VITE_API_BASE_URL=http://localhost:8000/api/v1
VITE_APP_NAME=MACOKI APMS
VITE_DEBUG=true
```

### Save as: `backend/.env.example`

```
# Django
DJANGO_SECRET_KEY=your-secret-key-here
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1

# Database
DATABASE_URL=postgresql://macoki_user:macoki_password@localhost:5432/macoki_apms

# CORS
CORS_ALLOWED_ORIGINS=http://localhost:5173

# JWT
JWT_SIGNING_KEY=your-jwt-signing-key-here

# Email (for production)
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-email-password
```

---

## 6. ROOT CONFIGURATION FILES

### Save as: `pyproject.toml` (Python)

```toml
[build-system]
requires = ["setuptools>=40.8.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "macoki-apms"
version = "0.1.0"
description = "Patient Management System for Nigerian Clinics"

[tool.pytest.ini_options]
DJANGO_SETTINGS_MODULE = "config.settings.development"
python_files = ["tests.py", "test_*.py", "*_tests.py"]

[tool.coverage.run]
source = ["apps", "common"]
omit = ["*/migrations/*", "*/tests.py"]

[tool.coverage.report]
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "raise AssertionError",
    "raise NotImplementedError",
    "if __name__ == .__main__.:",
]
```

### Save as: `frontend/package.json` (after npm init)

Add these scripts:
```json
{
  "name": "macoki-apms-frontend",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint src --ext ts,tsx",
    "format": "prettier --write src",
    "type-check": "tsc --noEmit",
    "test": "vitest",
    "test:watch": "vitest --watch",
    "test:coverage": "vitest --coverage"
  },
  "dependencies": {
    "react": "^19.3.0",
    "react-dom": "^19.3.0",
    "react-router-dom": "^6.20.0",
    "axios": "^1.6.0",
    "zustand": "^4.4.0",
    "zod": "^3.22.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.2.0",
    "typescript": "^5.3.0",
    "vite": "^5.0.0",
    "vitest": "^1.0.0",
    "@testing-library/react": "^14.1.0",
    "@testing-library/jest-dom": "^6.1.0",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0",
    "eslint": "^8.55.0",
    "prettier": "^3.1.0"
  }
}
```

### Save as: `backend/requirements.txt`

```
Django==5.2
djangorestframework==3.14
django-cors-headers==4.3
djangorestframework-simplejwt==5.3
python-decouple==3.8
python-dotenv==1.0
psycopg==3.1
gunicorn==21.2
whitenoise==6.6
```

### Save as: `backend/requirements-dev.txt`

```
-r requirements.txt

pytest==7.4
pytest-django==4.5
pytest-cov==4.1
pytest-watch==4.2
factory-boy==3.3
black==23.12
flake8==6.1
pylint==3.0
```

---

## 7. QUICK SETUP CHECKLIST

```markdown
# Repository Setup Checklist

- [ ] Run `setup-repo.sh` to create structure
- [ ] Create GitHub repository
- [ ] Clone and navigate to directory
- [ ] Initialize Git: `git init`
- [ ] Copy all files from this template
- [ ] Create branches: `main`, `develop`
- [ ] Configure branch protection on `main`
- [ ] Test Docker setup: `docker-compose up -d`
- [ ] Verify: Frontend at http://localhost:5173
- [ ] Verify: Backend at http://localhost:8000
- [ ] Verify: Postgres at localhost:5432
- [ ] Commit initial setup: `git commit -m "initial: project foundation"`
- [ ] Push to GitHub
- [ ] Verify GitHub Actions workflows run
- [ ] Create first sprint issues
- [ ] Assign tasks to team

**Total Setup Time:** 20-30 minutes
```

---

## 8. BRANCH PROTECTION SETTINGS

**For `main` branch:**
```
- Require pull request reviews before merging (1 approval)
- Require status checks to pass before merging
  - Frontend CI must pass
  - Backend CI must pass
  - Security Scan must pass
- Require branches to be up to date before merging
- Dismiss stale pull request approvals when new commits are pushed
```

---

## 9. TEAM COLLABORATION SETUP

### GitHub Teams

Create teams:
- `@macoki-apms/frontend-team`
- `@macoki-apms/backend-team`
- `@macoki-apms/devops-team`
- `@macoki-apms/maintainers`

### Repository Permissions

| Role | Permission |
|------|-----------|
| Frontend Team | Write access to `/frontend` |
| Backend Team | Write access to `/backend` |
| DevOps Team | Admin access to `.github`, `docker`, `docs` |
| Maintainers | Admin access (all) |

---

## 10. POST-SETUP TASKS

Once repository is ready:

1. **Create Sprint 1 Issues**
   - Use tasks from MACOKI_SPRINT_TASKS.md
   - Create GitHub Issues for each story
   - Add story points as labels
   - Assign to team members

2. **Set Up Project Board**
   - Create GitHub Projects board
   - Columns: Backlog, Sprint 1, In Progress, Review, Done
   - Add Sprint 1 issues

3. **Configure Wiki** (Optional)
   - Add architecture documentation
   - Add API documentation
   - Add deployment guides

4. **Set Up CI/CD Secrets**
   ```
   Repository Settings → Secrets and variables → Actions
   Add:
   - DOCKER_USERNAME (if using Docker Hub)
   - DOCKER_PASSWORD
   - VERCEL_TOKEN (for frontend deployment)
   - RENDER_TOKEN (for backend deployment)
   ```

5. **Schedule First Standup**
   - Daily 15-minute sync
   - Review progress, blockers, plan day

---

## Quick Start Command

```bash
# Clone and setup
git clone https://github.com/your-org/macoki-apms.git
cd macoki-apms
docker-compose up -d

# Verify
curl http://localhost:5173  # Frontend
curl http://localhost:8000/api/v1/health/  # Backend

# Start development
# Create a feature branch and start Sprint 1!
```

---

**Repository template ready to use!** 🎉
