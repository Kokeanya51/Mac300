-- MACOKI APMS - PostgreSQL Database Schema
-- Section 09: Complete Database Structure
-- Created: September 11, 2026

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- USERS & AUTHENTICATION
-- ============================================================================

-- Roles/Permissions table
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (name, description) VALUES
    ('ADMIN', 'System administrator with full access'),
    ('CLINICIAN', 'Healthcare worker - clinical access'),
    ('COMMUNITY_HEALTH_WORKER', 'Community health worker'),
    ('RECEPTION', 'Reception/registration staff'),
    ('RECORDS', 'Records management staff'),
    ('MANAGEMENT', 'Clinic management/administration');

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(150) UNIQUE NOT NULL,
    email VARCHAR(254) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(150),
    last_name VARCHAR(150),
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    is_staff BOOLEAN DEFAULT FALSE,
    is_superuser BOOLEAN DEFAULT FALSE,
    date_joined TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    role_id INTEGER REFERENCES roles(id),
    clinic_id UUID,  -- Future: link to clinic
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on username for login performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_is_active ON users(is_active);

-- ============================================================================
-- PATIENTS
-- ============================================================================

CREATE TABLE patients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    patient_id VARCHAR(50) UNIQUE NOT NULL,  -- MAC-PAT-000001 format
    first_name VARCHAR(150) NOT NULL,
    last_name VARCHAR(150) NOT NULL,
    other_names VARCHAR(150),
    date_of_birth DATE,
    age_at_registration INTEGER,
    sex VARCHAR(1) CHECK (sex IN ('M', 'F', 'O')),  -- Male, Female, Other
    phone VARCHAR(20),
    phone_secondary VARCHAR(20),
    address TEXT,
    lga VARCHAR(100),  -- Local Government Area
    state VARCHAR(100),
    next_of_kin VARCHAR(150),
    next_of_kin_phone VARCHAR(20),
    next_of_kin_relationship VARCHAR(50),
    emergency_contact VARCHAR(150),
    emergency_contact_phone VARCHAR(20),
    marital_status VARCHAR(20),  -- Single, Married, Widowed, Divorced
    occupation VARCHAR(100),
    education_level VARCHAR(50),  -- Primary, Secondary, Tertiary, None
    registration_date DATE NOT NULL,
    last_visit_date DATE,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for frequent queries
CREATE UNIQUE INDEX idx_patients_patient_id ON patients(patient_id);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_first_name ON patients(first_name);
CREATE INDEX idx_patients_last_name ON patients(last_name);
CREATE INDEX idx_patients_created_at ON patients(created_at);
CREATE INDEX idx_patients_is_active ON patients(is_active);

-- ============================================================================
-- CLINICAL VISITS
-- ============================================================================

CREATE TABLE visits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visit_id VARCHAR(50) UNIQUE NOT NULL,  -- VIS-20260911-001 format
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    visit_date DATE NOT NULL,
    visit_time TIME,
    visit_type VARCHAR(50),  -- Initial, Follow-up, Emergency, Preventive
    chief_complaint TEXT,
    clinical_notes TEXT,
    assessment TEXT,
    diagnosis TEXT,
    treatment_plan TEXT,
    medications_prescribed TEXT,
    referral_notes TEXT,
    followup_instructions TEXT,
    healthcare_worker_id UUID REFERENCES users(id),
    supervised_by UUID REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'COMPLETED',  -- DRAFT, COMPLETED, CLOSED
    is_final BOOLEAN DEFAULT FALSE,  -- Prevents editing after finalization
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_visits_patient_id ON visits(patient_id);
CREATE INDEX idx_visits_visit_date ON visits(visit_date);
CREATE INDEX idx_visits_healthcare_worker_id ON visits(healthcare_worker_id);
CREATE INDEX idx_visits_created_at ON visits(created_at);

-- ============================================================================
-- VITAL SIGNS
-- ============================================================================

CREATE TABLE vital_signs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visit_id UUID NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
    temperature_celsius DECIMAL(5, 2),  -- Celsius
    blood_pressure_systolic INTEGER,  -- mmHg
    blood_pressure_diastolic INTEGER,  -- mmHg
    pulse_rate INTEGER,  -- beats per minute
    respiratory_rate INTEGER,  -- breaths per minute
    weight_kg DECIMAL(6, 2),  -- Kilograms
    height_cm DECIMAL(6, 2),  -- Centimeters (for BMI calculation)
    oxygen_saturation INTEGER,  -- SpO2 percentage
    blood_glucose_mmol DECIMAL(6, 2),  -- Mmol/L (if measured)
    measured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_vital_signs_visit_id ON vital_signs(visit_id);
CREATE INDEX idx_vital_signs_measured_at ON vital_signs(measured_at);

-- ============================================================================
-- FOLLOW-UP MANAGEMENT
-- ============================================================================

CREATE TABLE follow_ups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    followup_id VARCHAR(50) UNIQUE NOT NULL,  -- FUP-20260918-001 format
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
    visit_id UUID REFERENCES visits(id) ON DELETE SET NULL,
    followup_date DATE NOT NULL,
    followup_type VARCHAR(50) NOT NULL,  -- ROUTINE_REVIEW, MEDICATION_REVIEW, CONDITION_MONITORING, MCH_VISIT, POST_TREATMENT, OTHER
    reason TEXT,
    priority VARCHAR(20) DEFAULT 'NORMAL',  -- LOW, NORMAL, HIGH, URGENT
    notes TEXT,
    status VARCHAR(20) DEFAULT 'PENDING',  -- PENDING, DUE, OVERDUE, COMPLETED, CANCELLED
    completed_date DATE,
    completed_by UUID REFERENCES users(id),
    completion_notes TEXT,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_followups_patient_id ON follow_ups(patient_id);
CREATE INDEX idx_followups_followup_date ON follow_ups(followup_date);
CREATE INDEX idx_followups_status ON follow_ups(status);
CREATE INDEX idx_followups_priority ON follow_ups(priority);
CREATE INDEX idx_followups_created_at ON follow_ups(created_at);

-- ============================================================================
-- SYNCHRONIZATION (Offline-First)
-- ============================================================================

CREATE TABLE sync_operations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    operation_id VARCHAR(50) UNIQUE NOT NULL,
    device_id VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,  -- 'patient', 'visit', 'vital_signs', 'follow_up'
    entity_id UUID NOT NULL,
    operation VARCHAR(20) NOT NULL,  -- CREATE, UPDATE, DELETE
    payload JSONB,  -- Full object data
    status VARCHAR(20) DEFAULT 'PENDING',  -- PENDING, SYNCING, SYNCED, FAILED, CONFLICT
    retry_count INTEGER DEFAULT 0,
    last_error TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    synced_at TIMESTAMP
);

CREATE INDEX idx_sync_operations_status ON sync_operations(status);
CREATE INDEX idx_sync_operations_device_id ON sync_operations(device_id);
CREATE INDEX idx_sync_operations_created_at ON sync_operations(created_at);
CREATE INDEX idx_sync_operations_entity ON sync_operations(entity_type, entity_id);

-- ============================================================================
-- AUDIT LOGGING
-- ============================================================================

CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,  -- CREATE_PATIENT, UPDATE_VISIT, etc.
    entity_type VARCHAR(50) NOT NULL,  -- patient, visit, follow_up, etc.
    entity_id UUID NOT NULL,
    object_data JSONB,  -- Before/after values
    ip_address INET,
    user_agent TEXT,
    status VARCHAR(20) DEFAULT 'SUCCESS',  -- SUCCESS, FAILURE
    error_message TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity_type ON audit_logs(entity_type);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

-- ============================================================================
-- SYNC METADATA (Version Control)
-- ============================================================================

CREATE TABLE sync_metadata (
    id SERIAL PRIMARY KEY,
    entity_type VARCHAR(50) NOT NULL,
    entity_id UUID NOT NULL,
    version INTEGER DEFAULT 1,
    last_synced_at TIMESTAMP,
    last_modified_by UUID REFERENCES users(id),
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(entity_type, entity_id)
);

CREATE INDEX idx_sync_metadata_entity ON sync_metadata(entity_type, entity_id);
CREATE INDEX idx_sync_metadata_last_synced ON sync_metadata(last_synced_at);

-- ============================================================================
-- NOTIFICATIONS (Future Enhancement)
-- ============================================================================

CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    follow_up_id UUID REFERENCES follow_ups(id) ON DELETE CASCADE,
    notification_type VARCHAR(50),  -- APPOINTMENT_REMINDER, OVERDUE_ALERT, SYSTEM
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- ============================================================================
-- VIEWS (Aggregations for Dashboard)
-- ============================================================================

-- View: Today's Follow-ups Summary
CREATE OR REPLACE VIEW v_todays_followups AS
SELECT 
    fu.followup_id,
    fu.patient_id,
    p.first_name,
    p.last_name,
    p.phone,
    fu.followup_type,
    fu.reason,
    fu.priority,
    fu.status,
    fu.followup_date,
    u.first_name AS created_by_first_name,
    u.last_name AS created_by_last_name
FROM follow_ups fu
JOIN patients p ON fu.patient_id = p.id
JOIN users u ON fu.created_by = u.id
WHERE fu.followup_date = CURRENT_DATE
  AND fu.status IN ('PENDING', 'DUE')
ORDER BY fu.priority DESC, fu.followup_date ASC;

-- View: Overdue Follow-ups
CREATE OR REPLACE VIEW v_overdue_followups AS
SELECT 
    fu.followup_id,
    fu.patient_id,
    p.first_name,
    p.last_name,
    p.phone,
    fu.followup_type,
    fu.reason,
    fu.priority,
    (CURRENT_DATE - fu.followup_date) AS days_overdue
FROM follow_ups fu
JOIN patients p ON fu.patient_id = p.id
WHERE fu.followup_date < CURRENT_DATE
  AND fu.status IN ('PENDING', 'OVERDUE')
ORDER BY days_overdue DESC;

-- View: Patient with Recent Visits
CREATE OR REPLACE VIEW v_patients_recent_visits AS
SELECT 
    p.id,
    p.patient_id,
    p.first_name,
    p.last_name,
    p.phone,
    p.age_at_registration,
    p.sex,
    COUNT(v.id) AS total_visits,
    MAX(v.visit_date) AS last_visit_date,
    MAX(v.created_at) AS last_visit_created_at
FROM patients p
LEFT JOIN visits v ON p.id = v.patient_id
WHERE p.is_active = TRUE
GROUP BY p.id, p.patient_id, p.first_name, p.last_name, p.phone, p.age_at_registration, p.sex
ORDER BY last_visit_date DESC;

-- ============================================================================
-- CONSTRAINTS & TRIGGERS
-- ============================================================================

-- Ensure follow_up_date is in the future
ALTER TABLE follow_ups 
ADD CONSTRAINT chk_followup_date CHECK (followup_date >= CURRENT_DATE);

-- Trigger to update follow_up status automatically
CREATE OR REPLACE FUNCTION update_followup_status()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.followup_date = CURRENT_DATE THEN
        NEW.status = 'DUE';
    ELSIF NEW.followup_date < CURRENT_DATE AND NEW.status = 'PENDING' THEN
        NEW.status = 'OVERDUE';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_followup_status
BEFORE INSERT OR UPDATE ON follow_ups
FOR EACH ROW
EXECUTE FUNCTION update_followup_status();

-- Trigger to update patient's last_visit_date
CREATE OR REPLACE FUNCTION update_patient_last_visit()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE patients SET last_visit_date = NEW.visit_date
    WHERE id = NEW.patient_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_patient_last_visit
AFTER INSERT OR UPDATE ON visits
FOR EACH ROW
EXECUTE FUNCTION update_patient_last_visit();

-- Trigger to auto-update sync_metadata version
CREATE OR REPLACE FUNCTION increment_sync_version()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE sync_metadata 
    SET version = version + 1, updated_at = CURRENT_TIMESTAMP
    WHERE entity_type = NEW.entity_type AND entity_id = NEW.entity_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- GRANTS & PERMISSIONS
-- ============================================================================

-- Create read-only role for clinicians
CREATE ROLE clinician_readonly;
GRANT CONNECT ON DATABASE macoki TO clinician_readonly;
GRANT USAGE ON SCHEMA public TO clinician_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO clinician_readonly;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO clinician_readonly;

-- Create application role (full access)
CREATE ROLE app_user;
GRANT CONNECT ON DATABASE macoki TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO app_user;

-- ============================================================================
-- SAMPLE DATA (Development Only - Remove in Production)
-- ============================================================================

-- Insert test user
-- INSERT INTO users (username, email, password_hash, first_name, last_name, role_id, is_active)
-- VALUES ('amara', 'amara@clinic.example.com', 'hashed_password_here', 'Amara', 'Okonkwo', 1, TRUE);

-- Insert test patient
-- INSERT INTO patients (patient_id, first_name, last_name, sex, phone, address, registration_date, created_by)
-- VALUES ('MAC-PAT-000001', 'Chidinma', 'Okeke', 'F', '08000000000', 'Ikwuano', CURRENT_DATE, 'user_uuid_here');

-- ============================================================================
-- MAINTENANCE NOTES
-- ============================================================================

-- Regular maintenance tasks:
-- 1. VACUUM ANALYZE; -- Weekly
-- 2. REINDEX; -- Monthly
-- 3. Backup database -- Daily
-- 4. Archive old audit logs -- Monthly

-- Performance tuning:
-- 1. Analyze slow queries: EXPLAIN ANALYZE SELECT ...;
-- 2. Monitor index usage
-- 3. Adjust work_mem if needed
-- 4. Enable connection pooling (PgBouncer)
