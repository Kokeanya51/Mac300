# MACOKI APMS — Implementation Planning Guide
## Converting AUXANO Sections 01–10 into Development Sprints

**Project:** MACOKI Patient Management System (APMS)  
**Status:** Ready for Implementation  
**Timeline:** 8 Sprints (~4-5 months for MVP)  
**Target Launch:** Q1 2027 (post BSc completion June 2027)  

---

## 1. IMPLEMENTATION PHASES OVERVIEW

### Phase 1: Foundation (Sprint 1)
**Goal:** Get the development environment and basic infrastructure running.

### Phase 2: Core Security (Sprints 2-3)
**Goal:** Implement authentication, authorization, and basic patient management.

### Phase 3: Clinical Features (Sprints 4-5)
**Goal:** Implement visit recording, follow-up tracking, and dashboard.

### Phase 4: Offline-First (Sprint 6)
**Goal:** Implement IndexedDB, synchronization engine, conflict handling.

### Phase 5: Quality & Launch (Sprints 7-8)
**Goal:** Audit trail, security hardening, testing, and production deployment.

---

## 2. SPRINT 1: PROJECT FOUNDATION

**Duration:** 1-2 weeks  
**Goal:** Establish development environment and basic project structure

### 2.1 GitHub Repository Setup

**Task 1.1: Create Monorepo Structure**
- Create GitHub organization/repository: `macoki-apms`
- Initialize main branch protection rules
- Set up `.gitignore`, `.dockerignore`, `README.md`, `LICENSE`
- Create branch strategy:
  - `main` → production (protected)
  - `develop` → integration branch
  - `feature/*` → feature branches
  - `hotfix/*` → production fixes

**Task 1.2: Create Directory Structure**
```bash
mkdir -p frontend backend docs docker scripts .github/workflows
```

**Task 1.3: Initialize README & Documentation**
- Create root `README.md` with project overview
- Create `DEVELOPMENT.md` for local setup instructions
- Create `CONTRIBUTING.md` for contribution guidelines

---

### 2.2 Frontend Project Setup

**Task 1.4: Initialize React + Vite + TypeScript**

```bash
cd frontend
npm create vite@latest . -- --template react-ts
npm install
npm install -D typescript @types/react @types/react-dom
npm install zustand axios zod react-router-dom
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
npm install -D @testing-library/react vitest
npm install axios-mock-adapter
```

**Task 1.5: Configure Vite, TypeScript, Tailwind**
- Update `vite.config.ts` with PWA plugin
- Update `tsconfig.json` with strict mode
- Configure `tailwind.config.ts` with custom theme
- Create `eslint.config.js` for code quality

**Task 1.6: Create Frontend Directory Structure**

```
frontend/src/
├── components/
│   ├── common/
│   ├── layout/
│   ├── auth/
│   └── ...
├── pages/
├── hooks/
├── stores/
├── services/
├── db/
├── sync/
├── routes/
├── types/
├── schemas/
├── utils/
├── config/
├── workers/
├── App.tsx
├── main.tsx
└── index.css
```

**Task 1.7: Create Environment Variables Template**

`frontend/.env.example`:
```
VITE_API_BASE_URL=http://localhost:8000/api/v1
VITE_APP_NAME=MACOKI APMS
VITE_DEBUG=true
```

**Acceptance Criteria:**
- React project created and runs locally
- TypeScript strict mode enabled
- Tailwind CSS configured
- File structure matches design
- `.env.example` created

---

### 2.3 Backend Project Setup

**Task 1.8: Initialize Django + DRF + PostgreSQL**

```bash
cd backend
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install django==5.2 djangorestframework django-cors-headers djangorestframework-simplejwt python-decouple psycopg python-dotenv
pip install pytest pytest-django pytest-cov
django-admin startproject config .
python manage.py startapp accounts
python manage.py startapp patients
python manage.py startapp visits
python manage.py startapp followups
python manage.py startapp synchronization
python manage.py startapp audit
python manage.py startapp dashboard
```

**Task 1.9: Configure Django Settings**

`backend/config/settings/base.py`:
- Set `DEBUG = False` for production
- Configure `INSTALLED_APPS` with all custom apps + rest_framework
- Configure `DATABASES` for PostgreSQL
- Set `SECRET_KEY` from environment
- Configure `ALLOWED_HOSTS` and `CORS_ALLOWED_ORIGINS`
- Add JWT authentication settings

```python
# Example
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'apps.accounts',
    'apps.patients',
    'apps.visits',
    'apps.followups',
    'apps.synchronization',
    'apps.audit',
    'apps.dashboard',
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 20,
}
```

**Task 1.10: Create Backend Directory Structure**

```
backend/
├── config/
│   ├── settings/
│   │   ├── base.py
│   │   ├── development.py
│   │   └── production.py
│   ├── urls.py
│   └── ...
├── apps/
│   ├── accounts/
│   ├── patients/
│   ├── visits/
│   ├── followups/
│   ├── synchronization/
│   ├── audit/
│   └── dashboard/
├── common/
│   ├── permissions/
│   ├── middleware/
│   ├── exceptions/
│   └── utilities/
├── tests/
├── manage.py
├── requirements.txt
└── .env.example
```

**Task 1.11: Create requirements.txt**

```
Django==5.2
djangorestframework==3.14
django-cors-headers==4.3
djangorestframework-simplejwt==5.3
python-decouple==3.8
python-dotenv==1.0
psycopg==3.1
gunicorn==21.2
whitenoise==6.6
pytest==7.4
pytest-django==4.5
```

**Task 1.12: Create Environment Variables Template**

`backend/.env.example`:
```
DJANGO_SECRET_KEY=your-secret-key-here
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1
DATABASE_URL=postgresql://user:password@localhost:5432/macoki_apms
CORS_ALLOWED_ORIGINS=http://localhost:5173
JWT_SIGNING_KEY=your-jwt-key-here
```

**Acceptance Criteria:**
- Django project created and migrations run
- All apps created and registered
- PostgreSQL configured
- JWT settings configured
- `.env.example` created
- Test runner configured

---

### 2.4 Docker & Local Development

**Task 1.13: Create Docker Compose**

`docker-compose.yml`:
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:18
    environment:
      POSTGRES_DB: macoki_apms
      POSTGRES_USER: macoki_user
      POSTGRES_PASSWORD: macoki_password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  backend:
    build: ./backend
    command: >
      sh -c "python manage.py migrate &&
             python manage.py runserver 0.0.0.0:8000"
    ports:
      - "8000:8000"
    volumes:
      - ./backend:/app
    environment:
      - DATABASE_URL=postgresql://macoki_user:macoki_password@postgres:5432/macoki_apms
      - DJANGO_SECRET_KEY=dev-secret-key
    depends_on:
      - postgres

  frontend:
    build: ./frontend
    ports:
      - "5173:5173"
    volumes:
      - ./frontend:/app
    command: npm run dev

volumes:
  postgres_data:
```

**Task 1.14: Create Dockerfiles**

`docker/frontend/Dockerfile`:
```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 5173

CMD ["npm", "run", "dev"]
```

`docker/backend/Dockerfile`:
```dockerfile
FROM python:3.13-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["gunicorn", "config.wsgi:application", "--bind", "0.0.0.0:8000"]
```

**Acceptance Criteria:**
- Docker Compose starts all services
- Frontend accessible at `http://localhost:5173`
- Backend accessible at `http://localhost:8000`
- PostgreSQL container runs and persists data
- Services can communicate

---

### 2.5 CI/CD Foundation

**Task 1.15: Create GitHub Actions Workflows**

`.github/workflows/frontend-ci.yml`:
```yaml
name: Frontend CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 20
      - run: cd frontend && npm ci
      - run: cd frontend && npm run lint
      - run: cd frontend && npm run test
      - run: cd frontend && npm run build
```

`.github/workflows/backend-ci.yml`:
```yaml
name: Backend CI

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.13'
      - run: cd backend && pip install -r requirements-dev.txt
      - run: cd backend && pytest
```

**Acceptance Criteria:**
- GitHub Actions workflows trigger on push
- Linting passes
- Basic tests pass
- Build succeeds

---

### 2.6 Sprint 1 Deliverables

- ✅ GitHub repository with branch protection
- ✅ Frontend: React + Vite + TypeScript + Tailwind
- ✅ Backend: Django + DRF + PostgreSQL
- ✅ Docker Compose for local development
- ✅ Environment configuration templates
- ✅ GitHub Actions CI/CD started
- ✅ All developers can clone and run locally

---

## 3. SPRINT 2: AUTHENTICATION & AUTHORIZATION

**Duration:** 1-2 weeks  
**Depends on:** Sprint 1 complete

### 3.1 Backend: User Model & JWT

**Task 2.1: Extend Django User Model**

`backend/apps/accounts/models.py`:
```python
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    """Extended user model with additional fields"""
    ROLE_CHOICES = (
        ('ADMIN', 'Administrator'),
        ('CLINICIAN', 'Clinician'),
        ('CHW', 'Community Health Worker'),
        ('RECEPTION', 'Reception'),
        ('RECORDS', 'Records'),
        ('MANAGEMENT', 'Management'),
    )
    
    phone_number = models.CharField(max_length=20, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'users'
        ordering = ['-created_at']
```

**Task 2.2: Create Role & Permission Models**

`backend/apps/accounts/models.py`:
```python
class Role(models.Model):
    name = models.CharField(max_length=50, unique=True)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class Permission(models.Model):
    code = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    
    def __str__(self):
        return self.code

class UserRole(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    assigned_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'role')

class RolePermission(models.Model):
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE)
    
    class Meta:
        unique_together = ('role', 'permission')
```

**Task 2.3: Create Serializers**

`backend/apps/accounts/serializers.py`:
```python
from rest_framework import serializers
from .models import User, Role, Permission

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role']

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name', 'description']
```

**Task 2.4: Create JWT Views**

`backend/apps/accounts/views.py`:
```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import User
from .serializers import UserSerializer, LoginSerializer

class LoginView(TokenObtainPairView):
    """User login endpoint"""
    serializer_class = LoginSerializer
    
    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']
        
        user = authenticate(username=username, password=password)
        if user is None:
            return Response(
                {"detail": "Invalid credentials"},
                status=status.HTTP_401_UNAUTHORIZED
            )
        
        refresh = RefreshToken.for_user(user)
        return Response({
            'access': str(refresh.access_token),
            'refresh': str(refresh),
            'user': UserSerializer(user).data
        })

class LogoutView(APIView):
    """User logout endpoint"""
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        refresh_token = request.data.get('refresh')
        token = RefreshToken(refresh_token)
        token.blacklist()
        return Response({"detail": "Logged out successfully"})

class CurrentUserView(APIView):
    """Get current user profile"""
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        serializer = UserSerializer(request.user)
        return Response(serializer.data)
```

**Task 2.5: Create Custom Permissions**

`backend/common/permissions/base.py`:
```python
from rest_framework.permissions import BasePermission

class IsAuthenticated(BasePermission):
    """Check if user is authenticated"""
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

class HasRole(BasePermission):
    """Check if user has specific role"""
    required_roles = []
    
    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            return False
        return request.user.role in self.required_roles

class IsAdmin(HasRole):
    required_roles = ['ADMIN']

class IsClinician(HasRole):
    required_roles = ['ADMIN', 'CLINICIAN']

class CanViewPatient(BasePermission):
    """Check if user can view patient records"""
    def has_permission(self, request, view):
        # All authenticated users can view patient records
        return bool(request.user and request.user.is_authenticated)
```

**Task 2.6: Configure JWT in Settings**

`backend/config/settings/base.py`:
```python
from datetime import timedelta

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=1),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ALGORITHM': 'HS256',
    'SIGNING_KEY': os.getenv('JWT_SIGNING_KEY', SECRET_KEY),
}
```

**Task 2.7: Create URL Routing**

`backend/apps/accounts/urls.py`:
```python
from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import LoginView, LogoutView, CurrentUserView

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('me/', CurrentUserView.as_view(), name='current_user'),
]

# Main URLs
# backend/config/urls.py
urlpatterns = [
    path('api/v1/auth/', include('apps.accounts.urls')),
    # ... other URLs
]
```

---

### 3.2 Frontend: Login & Auth Store

**Task 2.8: Create Auth Zustand Store**

`frontend/src/stores/authStore.ts`:
```typescript
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AuthState {
  user: any | null;
  accessToken: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  setAccessToken: (token: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      
      login: async (username: string, password: string) => {
        set({ isLoading: true, error: null });
        try {
          const response = await fetch('/api/v1/auth/login/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password }),
          });
          
          if (!response.ok) throw new Error('Login failed');
          
          const data = await response.json();
          set({
            user: data.user,
            accessToken: data.access,
            refreshToken: data.refresh,
            isAuthenticated: true,
          });
        } catch (error) {
          set({ error: error.message });
        } finally {
          set({ isLoading: false });
        }
      },
      
      logout: () => {
        set({
          user: null,
          accessToken: null,
          refreshToken: null,
          isAuthenticated: false,
        });
      },
      
      setAccessToken: (token: string) => {
        set({ accessToken: token });
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        user: state.user,
      }),
    }
  )
);
```

**Task 2.9: Create API Client with Interceptors**

`frontend/src/services/api/client.ts`:
```typescript
import axios from 'axios';
import { useAuthStore } from '../../stores/authStore';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add JWT
apiClient.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor to handle token refresh
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      const authStore = useAuthStore.getState();
      if (authStore.refreshToken) {
        try {
          const response = await axios.post(
            `${import.meta.env.VITE_API_BASE_URL}/auth/token/refresh/`,
            { refresh: authStore.refreshToken }
          );
          authStore.setAccessToken(response.data.access);
          return apiClient(error.config);
        } catch {
          authStore.logout();
        }
      }
    }
    return Promise.reject(error);
  }
);

export default apiClient;
```

**Task 2.10: Create Login Page**

`frontend/src/pages/auth/LoginPage.tsx`:
```typescript
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../stores/authStore';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading, error } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await login(username, password);
    navigate('/dashboard');
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded shadow-lg">
        <h1 className="text-2xl font-bold mb-6">MACOKI APMS</h1>
        
        {error && <div className="text-red-500 mb-4">{error}</div>}
        
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full mb-4 p-2 border rounded"
        />
        
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-4 p-2 border rounded"
        />
        
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600"
        >
          {isLoading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  );
}
```

**Task 2.11: Create Protected Routes**

`frontend/src/routes/ProtectedRoute.tsx`:
```typescript
import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}
```

**Task 2.12: Update App Routes**

`frontend/src/App.tsx`:
```typescript
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ProtectedRoute } from './routes/ProtectedRoute';
import LoginPage from './pages/auth/LoginPage';
import DashboardPage from './pages/dashboard/DashboardPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
```

---

### 3.3 Database Migrations & Testing

**Task 2.13: Create and Run Migrations**

```bash
cd backend
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser  # Create admin user for testing
```

**Task 2.14: Write Tests**

`backend/tests/test_auth.py`:
```python
import pytest
from django.test import Client
from django.contrib.auth import get_user_model

User = get_user_model()

@pytest.mark.django_db
class TestAuthentication:
    def setup_method(self):
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            password='testpass123',
            role='CLINICIAN'
        )
    
    def test_login_success(self):
        response = self.client.post('/api/v1/auth/login/', {
            'username': 'testuser',
            'password': 'testpass123'
        })
        assert response.status_code == 200
        assert 'access' in response.json()
        assert 'refresh' in response.json()
    
    def test_login_invalid_credentials(self):
        response = self.client.post('/api/v1/auth/login/', {
            'username': 'testuser',
            'password': 'wrongpassword'
        })
        assert response.status_code == 401
    
    def test_current_user_requires_auth(self):
        response = self.client.get('/api/v1/auth/me/')
        assert response.status_code == 401
```

---

### 3.4 Sprint 2 Deliverables

- ✅ JWT authentication working
- ✅ User login/logout endpoints
- ✅ Role-based access control setup
- ✅ Protected routes in frontend
- ✅ Auth store with token management
- ✅ API client with JWT interceptors
- ✅ Login page functional
- ✅ Database migrations complete
- ✅ Tests passing

---

## 4. SPRINT 3: PATIENT MANAGEMENT

**Duration:** 1-2 weeks  
**Depends on:** Sprint 2 complete

### 4.1 Backend: Patient Model

**Task 3.1: Create Patient Model**

`backend/apps/patients/models.py`:
```python
from django.db import models
from django.contrib.auth import get_user_model
import uuid

User = get_user_model()

def generate_patient_number():
    """Generate unique patient number like MAC-PAT-000001"""
    from django.db.models import Max
    latest = Patient.objects.all().aggregate(Max('id'))
    next_id = (latest['id__max'] or 0) + 1
    return f'MAC-PAT-{next_id:06d}'

class Patient(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    patient_number = models.CharField(
        max_length=30,
        unique=True,
        default=generate_patient_number
    )
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    other_name = models.CharField(max_length=100, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    sex = models.CharField(
        max_length=20,
        choices=[('M', 'Male'), ('F', 'Female'), ('O', 'Other')]
    )
    phone_number = models.CharField(max_length=30, blank=True)
    address = models.TextField(blank=True)
    next_of_kin_name = models.CharField(max_length=200, blank=True)
    next_of_kin_phone = models.CharField(max_length=30, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    is_active = models.BooleanField(default=True)
    version = models.IntegerField(default=1)
    
    class Meta:
        db_table = 'patients'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['patient_number']),
            models.Index(fields=['phone_number']),
            models.Index(fields=['last_name', 'first_name']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f'{self.patient_number} - {self.first_name} {self.last_name}'
```

**Task 3.2: Create Serializers**

`backend/apps/patients/serializers.py`:
```python
from rest_framework import serializers
from .models import Patient

class PatientSerializer(serializers.ModelSerializer):
    age = serializers.SerializerMethodField()
    
    class Meta:
        model = Patient
        fields = [
            'id', 'patient_number', 'first_name', 'last_name',
            'date_of_birth', 'age', 'sex', 'phone_number', 'address',
            'next_of_kin_name', 'created_at', 'is_active'
        ]
    
    def get_age(self, obj):
        from datetime import date
        if obj.date_of_birth:
            today = date.today()
            return today.year - obj.date_of_birth.year
        return None

class PatientDetailSerializer(PatientSerializer):
    class Meta(PatientSerializer.Meta):
        fields = PatientSerializer.Meta.fields + [
            'updated_at', 'created_by', 'version'
        ]
```

**Task 3.3: Create ViewSet**

`backend/apps/patients/views.py`:
```python
from rest_framework import viewsets, filters, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from .models import Patient
from .serializers import PatientSerializer, PatientDetailSerializer

class PatientViewSet(viewsets.ModelViewSet):
    """Patient management viewset"""
    queryset = Patient.objects.filter(is_active=True)
    serializer_class = PatientSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['sex', 'is_active']
    search_fields = ['first_name', 'last_name', 'phone_number', 'patient_number']
    
    def get_serializer_class(self):
        if self.action == 'retrieve':
            return PatientDetailSerializer
        return PatientSerializer
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    @action(detail=False, methods=['get'])
    def search(self, request):
        """Search patients by name or phone"""
        query = request.query_params.get('q', '')
        patients = self.get_queryset().filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(phone_number__icontains=query) |
            Q(patient_number__icontains=query)
        )[:20]  # Limit results
        serializer = self.get_serializer(patients, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['get'])
    def history(self, request, pk=None):
        """Get patient's clinical history (visits)"""
        patient = self.get_object()
        visits = patient.visits.all().order_by('-visit_date')
        from apps.visits.serializers import VisitSerializer
        serializer = VisitSerializer(visits, many=True)
        return Response(serializer.data)
```

**Task 3.4: Register Viewset in URLs**

`backend/apps/patients/urls.py`:
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PatientViewSet

router = DefaultRouter()
router.register(r'', PatientViewSet, basename='patient')

urlpatterns = [
    path('', include(router.urls)),
]

# In main config/urls.py
urlpatterns = [
    path('api/v1/patients/', include('apps.patients.urls')),
]
```

---

### 4.2 Frontend: Patient List & Registration

**Task 3.5: Create Patient Service**

`frontend/src/services/patients/patientService.ts`:
```typescript
import apiClient from '../api/client';

export const patientService = {
  async list(params = {}) {
    const response = await apiClient.get('/patients/', { params });
    return response.data;
  },
  
  async search(query: string) {
    const response = await apiClient.get('/patients/search/', {
      params: { q: query },
    });
    return response.data;
  },
  
  async get(patientId: string) {
    const response = await apiClient.get(`/patients/${patientId}/`);
    return response.data;
  },
  
  async create(data: any) {
    const response = await apiClient.post('/patients/', data);
    return response.data;
  },
  
  async update(patientId: string, data: any) {
    const response = await apiClient.patch(`/patients/${patientId}/`, data);
    return response.data;
  },
  
  async getHistory(patientId: string) {
    const response = await apiClient.get(`/patients/${patientId}/history/`);
    return response.data;
  },
};
```

**Task 3.6: Create Patient Store**

`frontend/src/stores/patientStore.ts`:
```typescript
import { create } from 'zustand';
import { patientService } from '../services/patients/patientService';

interface PatientStore {
  patients: any[];
  currentPatient: any | null;
  isLoading: boolean;
  error: string | null;
  
  searchPatients: (query: string) => Promise<void>;
  getPatient: (id: string) => Promise<void>;
  registerPatient: (data: any) => Promise<void>;
  updatePatient: (id: string, data: any) => Promise<void>;
}

export const usePatientStore = create<PatientStore>((set) => ({
  patients: [],
  currentPatient: null,
  isLoading: false,
  error: null,
  
  searchPatients: async (query: string) => {
    set({ isLoading: true, error: null });
    try {
      const data = await patientService.search(query);
      set({ patients: data });
    } catch (error) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },
  
  getPatient: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      const patient = await patientService.get(id);
      set({ currentPatient: patient });
    } catch (error) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },
  
  registerPatient: async (data: any) => {
    set({ isLoading: true, error: null });
    try {
      const patient = await patientService.create(data);
      set((state) => ({
        patients: [patient, ...state.patients],
        currentPatient: patient,
      }));
    } catch (error) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },
  
  updatePatient: async (id: string, data: any) => {
    set({ isLoading: true, error: null });
    try {
      const updated = await patientService.update(id, data);
      set({ currentPatient: updated });
    } catch (error) {
      set({ error: error.message });
    } finally {
      set({ isLoading: false });
    }
  },
}));
```

**Task 3.7: Create Patient Registration Page**

`frontend/src/pages/patients/PatientRegistrationPage.tsx`:
```typescript
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePatientStore } from '../../stores/patientStore';

export default function PatientRegistrationPage() {
  const { registerPatient, isLoading, error } = usePatientStore();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    date_of_birth: '',
    sex: 'M',
    phone_number: '',
    address: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await registerPatient(formData);
    navigate('/patients');
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Register New Patient</h1>
      
      {error && <div className="text-red-500 mb-4">{error}</div>}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <input
            type="text"
            name="first_name"
            placeholder="First Name"
            value={formData.first_name}
            onChange={handleChange}
            required
            className="p-2 border rounded"
          />
          <input
            type="text"
            name="last_name"
            placeholder="Last Name"
            value={formData.last_name}
            onChange={handleChange}
            required
            className="p-2 border rounded"
          />
        </div>
        
        <input
          type="date"
          name="date_of_birth"
          value={formData.date_of_birth}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />
        
        <select
          name="sex"
          value={formData.sex}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        >
          <option value="M">Male</option>
          <option value="F">Female</option>
          <option value="O">Other</option>
        </select>
        
        <input
          type="tel"
          name="phone_number"
          placeholder="Phone Number"
          value={formData.phone_number}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />
        
        <textarea
          name="address"
          placeholder="Address"
          value={formData.address}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        />
        
        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 disabled:bg-gray-400"
        >
          {isLoading ? 'Registering...' : 'Register Patient'}
        </button>
      </form>
    </div>
  );
}
```

**Task 3.8: Create Patient Search Component**

`frontend/src/components/patients/PatientSearch.tsx`:
```typescript
import { useState } from 'react';
import { usePatientStore } from '../../stores/patientStore';

export default function PatientSearch() {
  const [query, setQuery] = useState('');
  const { searchPatients, patients, isLoading } = usePatientStore();

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      await searchPatients(query);
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSearch} className="flex gap-2">
        <input
          type="text"
          placeholder="Search by name, phone, or ID..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="flex-1 p-2 border rounded"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </form>
      
      {patients.length > 0 && (
        <div className="space-y-2">
          {patients.map((patient) => (
            <div key={patient.id} className="p-4 border rounded bg-gray-50">
              <div className="font-bold">{patient.patient_number}</div>
              <div>{patient.first_name} {patient.last_name}</div>
              <div className="text-gray-600">{patient.phone_number}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
```

---

### 4.3 Sprint 3 Deliverables

- ✅ Patient model with unique numbering
- ✅ Patient registration endpoint
- ✅ Patient search endpoint
- ✅ Patient profile/detail view
- ✅ Patient history endpoint
- ✅ Frontend patient registration form
- ✅ Frontend patient search component
- ✅ Patient list page
- ✅ Database indexes optimized
- ✅ Tests for patient endpoints

---

## 5. SPRINTS 4–8 SUMMARY

**Sprint 4: Clinical Visits & Vitals**
- Visit model, recording endpoints
- Vitals model and endpoints
- Visit list/detail views
- Frontend visit form

**Sprint 5: Follow-up & Dashboard**
- Follow-up model and management
- Dashboard summary/metrics endpoints
- Follow-up filtering (today/overdue/upcoming)
- Frontend dashboard

**Sprint 6: Offline-First System**
- IndexedDB database schema
- Sync engine implementation
- Conflict detection/resolution
- Network monitoring
- Sync push/pull endpoints

**Sprint 7: Audit, Security & Hardening**
- Audit log model
- Audit middleware
- Rate limiting
- Input validation
- Error handling
- CORS configuration

**Sprint 8: Testing & Deployment**
- Comprehensive test coverage
- Docker build and optimization
- Vercel deployment setup
- Render deployment setup
- Production PostgreSQL setup
- Backup/recovery testing

---

## 6. DEVELOPMENT WORKFLOW

### Git Workflow

```bash
# Start a feature
git checkout develop
git pull origin develop
git checkout -b feature/patient-registration

# Make changes, commit
git add .
git commit -m "feat: implement patient registration"

# Push and create PR
git push origin feature/patient-registration
# Create PR on GitHub for code review

# After approval, merge to develop
git checkout develop
git merge feature/patient-registration
git push origin develop

# CI/CD automatically runs tests and deploys to staging
```

### Local Development

```bash
# Clone repository
git clone https://github.com/your-org/macoki-apms.git
cd macoki-apms

# Start all services
docker-compose up -d

# Backend setup
cd backend
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver

# Frontend setup (in new terminal)
cd frontend
npm install
npm run dev

# Access at:
# Frontend: http://localhost:5173
# Backend: http://localhost:8000
# Admin: http://localhost:8000/admin
```

---

## 7. TESTING STRATEGY

### Backend Testing

```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_auth.py

# Run with coverage
pytest --cov=apps

# Run only fast tests
pytest -m "not slow"
```

### Frontend Testing

```bash
# Run tests
npm run test

# Run with coverage
npm run test:coverage

# Watch mode
npm run test:watch
```

### Integration Testing

```bash
# Test full flow: login → register patient → record visit → sync
docker-compose up -d
# Run test suite
npm run test:integration
```

---

## 8. DEPLOYMENT MILESTONES

**Pre-Production Checklist:**
- [ ] All tests passing
- [ ] Code review completed
- [ ] Security scan passing
- [ ] Database migrations tested
- [ ] Environment variables configured
- [ ] SSL certificate installed
- [ ] Backup procedure tested
- [ ] Disaster recovery plan documented

**Production Deployment:**
- [ ] Tag release: `v0.1.0-mvp`
- [ ] Deploy backend to Render
- [ ] Deploy frontend to Vercel
- [ ] Run smoke tests
- [ ] Monitor error rates
- [ ] Verify backups running

---

## 9. SUCCESS CRITERIA

Sprint completion requires:
- ✅ All acceptance criteria met
- ✅ Code coverage >80%
- ✅ No critical bugs
- ✅ All tests passing
- ✅ Code reviewed and approved
- ✅ Documentation updated

MVP Launch requires:
- ✅ All 8 sprints complete
- ✅ Amara can register a patient in <2 minutes
- ✅ Amara can record a visit in <1 minute
- ✅ Dashboard shows follow-ups accurately
- ✅ Offline mode works reliably
- ✅ Sync handles conflicts correctly
- ✅ Audit trail complete
- ✅ No data loss scenarios

---

## 10. NEXT STEPS

1. **Create GitHub Repository**
   - Set up branch protection
   - Configure CI/CD
   - Add team members

2. **Set Up Local Development**
   - Clone repo
   - Run `docker-compose up`
   - Verify all services running

3. **Sprint 1 Kickoff**
   - Assign tasks to developers
   - Set up daily standups
   - Begin implementation

4. **Weekly Reviews**
   - Demo completed features
   - Retrospective on blockers
   - Plan next sprint

---

**Questions or need adjustments to the sprint plan? Let me know!**
