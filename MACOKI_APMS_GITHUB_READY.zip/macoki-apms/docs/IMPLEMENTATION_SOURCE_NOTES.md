# Source alignment

This repository was assembled from the uploaded MACOKI APMS implementation materials.

Core MVP scope retained:
1. Patient registration
2. Patient search and lookup
3. Patient profile/history data model
4. Quick clinical visit recording
5. Follow-up tracking
6. Dashboard workflow
7. Offline-first local storage
8. Synchronization data structures
9. Authentication/RBAC foundation
10. Audit-log foundation

The supplied architecture identifies React 19.3 + TypeScript + Vite + Tailwind, Django 5.2 + DRF, PostgreSQL 18, JWT, IndexedDB + Service Worker, and Docker as the intended stack. This starter uses React/JS and plain CSS for a smaller directly runnable frontend while retaining the same frontend/backend/database separation.
