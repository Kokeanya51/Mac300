# MACOKI APMS — Detailed Sprint Tasks & User Stories

**Project:** MACOKI Patient Management System (APMS)  
**Purpose:** Actionable sprint tasks with user stories, acceptance criteria, dependencies, and estimates  
**Format:** Each task is assignable to a developer

---

## SPRINT 1: PROJECT FOUNDATION
**Duration:** 1-2 weeks | **Estimate:** 40-50 story points

### Epic 1.1: GitHub Repository & Project Setup

**Story 1.1.1: Create GitHub Repository & Configure Branch Protection**
- **User Story:** As a project manager, I want a GitHub repository with proper branch protection so that all code changes go through review before merging.
- **Acceptance Criteria:**
  - [ ] Repository created at `github.com/[org]/macoki-apms`
  - [ ] `main` branch has protection rules (require PR review, require status checks)
  - [ ] `develop` branch created and set as default
  - [ ] Branch naming convention documented (feature/*, hotfix/*)
  - [ ] README.md created with project overview
  - [ ] LICENSE file added (MIT/Apache)
  - [ ] CONTRIBUTING.md created with contribution guidelines
- **Dependencies:** None
- **Blockers:** None
- **Assigned to:** [Project Lead]
- **Story Points:** 5
- **Acceptance Test:**
  ```bash
  # Verify branch protection
  curl https://api.github.com/repos/[org]/macoki-apms/branches/main \
    | jq '.protection'
  ```

---

**Story 1.1.2: Create Repository Directory Structure**
- **User Story:** As a developer, I want a well-organized directory structure so I can navigate the project easily.
- **Acceptance Criteria:**
  - [ ] Root directory contains: frontend/, backend/, docs/, docker/, scripts/, .github/
  - [ ] .gitignore excludes: node_modules/, venv/, *.pyc, .env, dist/, build/
  - [ ] .dockerignore excludes development files
  - [ ] Directory structure matches architectural design (Section 10)
  - [ ] README.md in each major folder explains its purpose
- **Dependencies:** Story 1.1.1
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 3
- **Verification:**
  ```bash
  find . -type d -name "node_modules" -o -name "venv" | wc -l  # Should be 0
  ```

---

**Story 1.1.3: Create DEVELOPMENT.md with Local Setup Instructions**
- **User Story:** As a new developer, I want clear setup instructions so I can get the project running locally in <30 minutes.
- **Acceptance Criteria:**
  - [ ] Step-by-step setup for frontend (Node + dependencies)
  - [ ] Step-by-step setup for backend (Python + venv + dependencies)
  - [ ] Docker setup instructions with docker-compose
  - [ ] Database initialization steps
  - [ ] Verification steps (e.g., "Visit http://localhost:5173")
  - [ ] Common issues & troubleshooting section
  - [ ] Estimated time for complete setup: <30 minutes
- **Dependencies:** Story 1.1.2
- **Blockers:** None
- **Assigned to:** [DevOps/Tech Lead]
- **Story Points:** 5

---

### Epic 1.2: Frontend Project Foundation

**Story 1.2.1: Initialize React + Vite + TypeScript**
- **User Story:** As a frontend developer, I want a React + Vite + TypeScript project so I can start building components immediately.
- **Acceptance Criteria:**
  - [ ] React 19.3 installed via Vite
  - [ ] TypeScript configured with strict mode
  - [ ] React Router installed and configured
  - [ ] Vite config optimized (build time <5 seconds)
  - [ ] `npm run dev` starts dev server on port 5173
  - [ ] `npm run build` produces optimized bundle
  - [ ] Hot Module Replacement (HMR) working
- **Dependencies:** Story 1.1.2
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 8
- **Verification:**
  ```bash
  cd frontend
  npm run dev &  # Should start on http://localhost:5173
  curl http://localhost:5173 | grep "react"
  ```

---

**Story 1.2.2: Configure Tailwind CSS & ESLint**
- **User Story:** As a frontend developer, I want Tailwind CSS and ESLint configured so I can write consistent, styled components.
- **Acceptance Criteria:**
  - [ ] Tailwind CSS installed and configured
  - [ ] `tailwind.config.ts` created with custom theme
  - [ ] ESLint configured with React/TypeScript rules
  - [ ] Prettier configured for code formatting
  - [ ] `npm run lint` passes without errors
  - [ ] `npm run format` auto-fixes formatting issues
- **Dependencies:** Story 1.2.1
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5
- **Verification:**
  ```bash
  npm run lint
  npm run format
  ```

---

**Story 1.2.3: Set up Frontend Directory Structure**
- **User Story:** As a developer, I want a consistent folder structure so new components fit naturally.
- **Acceptance Criteria:**
  - [ ] All directories from Section 10 created:
    - `src/components/`, `src/pages/`, `src/hooks/`, `src/stores/`, `src/services/`, etc.
  - [ ] Each directory has a README explaining its purpose
  - [ ] Index files created where appropriate
  - [ ] `.env.example` created with example variables
  - [ ] `vite.config.ts` configured with path aliases (@/)
- **Dependencies:** Story 1.2.1
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 3

---

**Story 1.2.4: Set up Vitest + React Testing Library**
- **User Story:** As a frontend developer, I want testing infrastructure ready so I can write tests from day one.
- **Acceptance Criteria:**
  - [ ] Vitest installed and configured
  - [ ] React Testing Library installed
  - [ ] Sample test passes: `npm run test`
  - [ ] Coverage report generated: `npm run test:coverage`
  - [ ] Tests run on file watch: `npm run test:watch`
  - [ ] GitHub Actions workflow configured to run tests
- **Dependencies:** Story 1.2.1
- **Blockers:** None
- **Assigned to:** [QA Lead]
- **Story Points:** 5

---

### Epic 1.3: Backend Project Foundation

**Story 1.3.1: Initialize Django 5.2 + DRF + PostgreSQL**
- **User Story:** As a backend developer, I want Django + DRF configured with PostgreSQL so I can start building API endpoints.
- **Acceptance Criteria:**
  - [ ] Django 5.2 LTS installed
  - [ ] Django REST Framework installed
  - [ ] Project structure created with `config/` and `apps/`
  - [ ] All apps registered: accounts, patients, visits, followups, synchronization, audit, dashboard
  - [ ] PostgreSQL configured (settings split: base, dev, prod)
  - [ ] `python manage.py migrate` runs successfully
  - [ ] Django admin accessible at `http://localhost:8000/admin`
- **Dependencies:** Story 1.1.2
- **Blockers:** PostgreSQL available locally or via Docker
- **Assigned to:** [Backend Lead]
- **Story Points:** 8
- **Verification:**
  ```bash
  cd backend
  python manage.py migrate
  python manage.py createsuperuser
  python manage.py runserver
  # Visit http://localhost:8000/admin
  ```

---

**Story 1.3.2: Configure Django Settings (base, dev, production)**
- **User Story:** As a backend developer, I want environment-specific settings so production secrets don't leak into development.
- **Acceptance Criteria:**
  - [ ] `config/settings/base.py` with shared settings
  - [ ] `config/settings/development.py` with DEBUG=True
  - [ ] `config/settings/production.py` with DEBUG=False
  - [ ] INSTALLED_APPS configured for all custom apps + DRF
  - [ ] Database configuration supports both SQLite (dev) and PostgreSQL (prod)
  - [ ] CORS configured for frontend at localhost:5173
  - [ ] SECRET_KEY loaded from environment
  - [ ] `.env.example` created with all required variables
- **Dependencies:** Story 1.3.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 1.3.3: Set up Backend Directory Structure**
- **User Story:** As a developer, I want the backend organized by domain so I can find code quickly.
- **Acceptance Criteria:**
  - [ ] `apps/` directory with: accounts, patients, visits, followups, synchronization, audit, dashboard
  - [ ] `common/` directory with: permissions/, middleware/, exceptions/, utilities/
  - [ ] `tests/` directory mirroring app structure
  - [ ] Each app has: models.py, serializers.py, views.py, urls.py, services.py, tests/
  - [ ] `manage.py` in root
  - [ ] `requirements.txt` and `requirements-dev.txt` created
- **Dependencies:** Story 1.3.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 3

---

**Story 1.3.4: Set up pytest + Django Test Infrastructure**
- **User Story:** As a backend developer, I want testing infrastructure ready so I can write tests from day one.
- **Acceptance Criteria:**
  - [ ] pytest installed with pytest-django
  - [ ] `pytest.ini` configured with Django settings
  - [ ] Sample test passes: `pytest`
  - [ ] Coverage report generated: `pytest --cov=apps`
  - [ ] Tests run on file watch: `pytest-watch`
  - [ ] Test database configured (SQLite in-memory or separate test DB)
  - [ ] GitHub Actions workflow configured to run tests
- **Dependencies:** Story 1.3.1
- **Blockers:** None
- **Assigned to:** [QA Lead]
- **Story Points:** 5

---

### Epic 1.4: Docker & Local Development

**Story 1.4.1: Create Docker Compose for Local Development**
- **User Story:** As a developer, I want `docker-compose up` to start all services so I don't need to manually manage dependencies.
- **Acceptance Criteria:**
  - [ ] `docker-compose.yml` at root
  - [ ] Services defined: postgres, backend, frontend
  - [ ] PostgreSQL image: postgres:18
  - [ ] Backend builds from `docker/backend/Dockerfile`
  - [ ] Frontend builds from `docker/frontend/Dockerfile`
  - [ ] Port mappings: 5432 (postgres), 8000 (backend), 5173 (frontend)
  - [ ] Environment variables passed to containers
  - [ ] Volumes mount source code for hot reload
  - [ ] `docker-compose up -d` starts all services
  - [ ] All services healthy: `docker-compose ps`
- **Dependencies:** Story 1.2.1, Story 1.3.1
- **Blockers:** Docker installed
- **Assigned to:** [DevOps/Tech Lead]
- **Story Points:** 8
- **Verification:**
  ```bash
  docker-compose up -d
  sleep 10
  docker-compose ps  # All healthy
  curl http://localhost:5173  # Frontend responsive
  curl http://localhost:8000/api/v1/  # Backend responsive
  docker-compose down
  ```

---

**Story 1.4.2: Create Dockerfiles for Frontend & Backend**
- **User Story:** As a DevOps engineer, I want optimized Dockerfiles so images are small and build quickly.
- **Acceptance Criteria:**
  - [ ] `docker/frontend/Dockerfile`: Node 20 alpine, multi-stage build
  - [ ] `docker/backend/Dockerfile`: Python 3.13 slim, multi-stage build
  - [ ] Frontend image size <100MB
  - [ ] Backend image size <200MB
  - [ ] `docker build` takes <2 minutes
  - [ ] .dockerignore excludes unnecessary files
  - [ ] Production builds use gunicorn/caddy (not dev servers)
- **Dependencies:** Story 1.4.1
- **Blockers:** None
- **Assigned to:** [DevOps/Tech Lead]
- **Story Points:** 5

---

**Story 1.4.3: Verify Docker Compose Works End-to-End**
- **User Story:** As a developer, I want to verify that the entire stack runs together before committing.
- **Acceptance Criteria:**
  - [ ] `docker-compose up` starts in <2 minutes
  - [ ] PostgreSQL initialized with test database
  - [ ] Backend migrations run automatically
  - [ ] Frontend dev server starts and serves assets
  - [ ] Backend responds to `/api/v1/health/` (create simple health endpoint)
  - [ ] Logs show no errors
  - [ ] Manual test: Frontend can reach backend (fetch to `/api/v1/health/`)
- **Dependencies:** Story 1.4.1, Story 1.4.2
- **Blockers:** None
- **Assigned to:** [DevOps/Tech Lead]
- **Story Points:** 3

---

### Epic 1.5: CI/CD Foundation

**Story 1.5.1: Create GitHub Actions Workflow for Frontend**
- **User Story:** As a developer, I want automated frontend tests on every push so we catch bugs early.
- **Acceptance Criteria:**
  - [ ] `.github/workflows/frontend-ci.yml` created
  - [ ] Triggers on: push, pull_request
  - [ ] Jobs: lint, test, build
  - [ ] Lint step runs ESLint
  - [ ] Test step runs Vitest
  - [ ] Build step runs `npm run build`
  - [ ] All jobs must pass before merge
  - [ ] Workflow completes in <5 minutes
- **Dependencies:** Story 1.2.4, Story 1.1.1
- **Blockers:** None
- **Assigned to:** [DevOps/QA Lead]
- **Story Points:** 5
- **Verification:**
  ```yaml
  # .github/workflows/frontend-ci.yml
  name: Frontend CI
  on: [push, pull_request]
  jobs:
    test:
      runs-on: ubuntu-latest
      steps:
        - uses: actions/checkout@v3
        - uses: actions/setup-node@v3
          with:
            node-version: 20
        - run: cd frontend && npm ci
        - run: cd frontend && npm run lint
        - run: cd frontend && npm run test
        - run: cd frontend && npm run build
  ```

---

**Story 1.5.2: Create GitHub Actions Workflow for Backend**
- **User Story:** As a developer, I want automated backend tests on every push so we catch API bugs early.
- **Acceptance Criteria:**
  - [ ] `.github/workflows/backend-ci.yml` created
  - [ ] Triggers on: push, pull_request
  - [ ] Jobs: lint, test
  - [ ] Lint step runs pylint/flake8
  - [ ] Test step runs pytest
  - [ ] Coverage report generated
  - [ ] Coverage threshold: >80%
  - [ ] All jobs must pass before merge
  - [ ] Workflow completes in <10 minutes
- **Dependencies:** Story 1.3.4, Story 1.1.1
- **Blockers:** None
- **Assigned to:** [DevOps/QA Lead]
- **Story Points:** 5

---

**Story 1.5.3: Create GitHub Actions Workflow for Security Scanning**
- **User Story:** As a security engineer, I want automated dependency scanning so we catch vulnerabilities early.
- **Acceptance Criteria:**
  - [ ] `.github/workflows/security-scan.yml` created
  - [ ] Dependabot enabled for npm and pip
  - [ ] Security scanning via GitHub CodeQL
  - [ ] Triggers on: push, schedule (weekly)
  - [ ] Reports surface critical vulnerabilities
  - [ ] Workflow runs in <10 minutes
- **Dependencies:** Story 1.1.1
- **Blockers:** None
- **Assigned to:** [Security/DevOps Lead]
- **Story Points:** 5

---

### Sprint 1 Summary

| Story | Title | Points | Assigned | Status |
|-------|-------|--------|----------|--------|
| 1.1.1 | GitHub Repository & Branch Protection | 5 | [PM] | - |
| 1.1.2 | Directory Structure | 3 | [Frontend] | - |
| 1.1.3 | DEVELOPMENT.md Setup Guide | 5 | [DevOps] | - |
| 1.2.1 | React + Vite + TypeScript | 8 | [Frontend] | - |
| 1.2.2 | Tailwind + ESLint | 5 | [Frontend] | - |
| 1.2.3 | Frontend Directory Structure | 3 | [Frontend] | - |
| 1.2.4 | Vitest + React Testing Library | 5 | [QA] | - |
| 1.3.1 | Django + DRF + PostgreSQL | 8 | [Backend] | - |
| 1.3.2 | Django Settings Configuration | 5 | [Backend] | - |
| 1.3.3 | Backend Directory Structure | 3 | [Backend] | - |
| 1.3.4 | pytest + Django Testing | 5 | [QA] | - |
| 1.4.1 | Docker Compose | 8 | [DevOps] | - |
| 1.4.2 | Dockerfiles | 5 | [DevOps] | - |
| 1.4.3 | End-to-End Verification | 3 | [DevOps] | - |
| 1.5.1 | Frontend CI/CD | 5 | [DevOps/QA] | - |
| 1.5.2 | Backend CI/CD | 5 | [DevOps/QA] | - |
| 1.5.3 | Security Scanning | 5 | [Security] | - |

**Total Sprint 1: 48 story points**

---

## SPRINT 2: AUTHENTICATION & AUTHORIZATION
**Duration:** 1-2 weeks | **Estimate:** 40-50 story points

### Epic 2.1: Backend User & JWT Setup

**Story 2.1.1: Extend Django User Model with Roles**
- **User Story:** As a system architect, I want a custom user model with roles so staff can have different permissions.
- **Acceptance Criteria:**
  - [ ] Custom User model created extending AbstractUser
  - [ ] Fields: phone_number, role (choices: ADMIN, CLINICIAN, CHW, RECEPTION, RECORDS, MANAGEMENT)
  - [ ] Model registered in Django admin
  - [ ] Migration created and tested
  - [ ] Superuser creation script handles role assignment
  - [ ] `__str__()` returns readable format: "username (ROLE)"
- **Dependencies:** Sprint 1 complete
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 2.1.2: Create Role & Permission Models**
- **User Story:** As a system architect, I want role-based permissions so we can grant fine-grained access.
- **Acceptance Criteria:**
  - [ ] Role model: id, name (unique), description
  - [ ] Permission model: id, code (unique), name, description
  - [ ] UserRole junction table: user, role, assigned_at
  - [ ] RolePermission junction table: role, permission
  - [ ] Unique constraints prevent duplicate assignments
  - [ ] Seed data script creates standard roles and permissions
  - [ ] Django admin interface works for all models
- **Dependencies:** Story 2.1.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 8

---

**Story 2.1.3: Configure SimpleJWT Authentication**
- **User Story:** As a backend developer, I want JWT tokens so frontend can send stateless auth with each request.
- **Acceptance Criteria:**
  - [ ] `djangorestframework-simplejwt` installed
  - [ ] JWT settings in Django config (access/refresh token lifetime)
  - [ ] Token creation/refresh working
  - [ ] Tokens include user ID and role in payload
  - [ ] Token validation works on protected endpoints
  - [ ] Token refresh endpoint functional
  - [ ] Tokens expire as configured (1 hour access, 7 days refresh)
- **Dependencies:** Story 2.1.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 2.1.4: Create Login Endpoint**
- **User Story:** As frontend developer, I want a login endpoint so users can authenticate.
- **Acceptance Criteria:**
  - [ ] POST `/api/v1/auth/login/` accepts username + password
  - [ ] Returns: access token, refresh token, user object
  - [ ] User object includes: id, username, email, first_name, last_name, role
  - [ ] Invalid credentials return 401
  - [ ] Rate limiting: max 5 attempts per minute per IP
  - [ ] Audit log: LOGIN_SUCCESS/LOGIN_FAILED created
  - [ ] Integration test passes
- **Dependencies:** Story 2.1.3
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 2.1.5: Create Logout Endpoint**
- **User Story:** As frontend developer, I want a logout endpoint so users can revoke their session.
- **Acceptance Criteria:**
  - [ ] POST `/api/v1/auth/logout/` requires authenticated user
  - [ ] Accepts refresh token for blacklisting
  - [ ] Token is added to blacklist (prevents reuse)
  - [ ] Returns 200 on success
  - [ ] Audit log: LOGOUT created
  - [ ] Subsequent requests with blacklisted token fail
  - [ ] Integration test passes
- **Dependencies:** Story 2.1.3
- **Blockers:** Token blacklist implementation (Redis or database)
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 2.1.6: Create Current User Endpoint**
- **User Story:** As frontend developer, I want to fetch current user profile so I can display it in the app.
- **Acceptance Criteria:**
  - [ ] GET `/api/v1/auth/me/` requires authenticated user
  - [ ] Returns full user object: id, username, email, first_name, last_name, role, phone_number
  - [ ] Returns 401 if not authenticated
  - [ ] Returns 401 if token expired
  - [ ] Response cached for 5 minutes
  - [ ] Integration test passes
- **Dependencies:** Story 2.1.4
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 3

---

### Epic 2.2: Role-Based Access Control

**Story 2.2.1: Create Custom Permission Classes**
- **User Story:** As backend developer, I want reusable permission classes so I can protect endpoints consistently.
- **Acceptance Criteria:**
  - [ ] `IsAuthenticated` permission class working
  - [ ] `IsAdmin` permission class working (only ADMIN role)
  - [ ] `IsClinician` permission class working (ADMIN or CLINICIAN)
  - [ ] `CanViewPatient` permission class working
  - [ ] `CanEditPatient` permission class working
  - [ ] Each class tested independently
  - [ ] Clear error messages on permission denied
- **Dependencies:** Story 2.2.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 8

---

**Story 2.2.2: Add Role-Based Access to Patient Endpoints**
- **User Story:** As backend developer, I want patient endpoints to enforce role-based access so only authorized staff can access them.
- **Acceptance Criteria:**
  - [ ] All authenticated users can view patient records
  - [ ] Only ADMIN/CLINICIAN can register new patients
  - [ ] Only ADMIN/CLINICIAN can update patient records
  - [ ] Only ADMIN can delete patient records
  - [ ] Audit logs track who accessed what
  - [ ] Tests verify permission enforcement at endpoint level
- **Dependencies:** Story 2.2.1
- **Blockers:** Patient endpoints exist (Sprint 3)
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 2.2.3: Create Audit Middleware for Permission Checks**
- **User Story:** As security engineer, I want to log all permission denials so we can detect unauthorized access attempts.
- **Acceptance Criteria:**
  - [ ] Middleware logs all 401/403 responses
  - [ ] Log includes: user, timestamp, endpoint, reason
  - [ ] Middleware doesn't slow down requests
  - [ ] Logs accessible via `/api/v1/audit/logs/`
  - [ ] Tests verify logging works
- **Dependencies:** Story 2.2.1
- **Blockers:** Audit model exists (Sprint 7)
- **Assigned to:** [Backend/Security Lead]
- **Story Points:** 5

---

### Epic 2.3: Frontend Authentication UI

**Story 2.3.1: Create Auth Zustand Store**
- **User Story:** As frontend developer, I want a centralized auth store so all components can access auth state.
- **Acceptance Criteria:**
  - [ ] Zustand store created with auth state
  - [ ] State includes: user, accessToken, refreshToken, isAuthenticated
  - [ ] Store persists tokens to localStorage
  - [ ] `login(username, password)` method calls API
  - [ ] `logout()` method clears state
  - [ ] `setAccessToken()` method for token refresh
  - [ ] Tests verify store logic
  - [ ] No tokens logged to console in production
- **Dependencies:** Sprint 1 complete
- **Blockers:** Story 2.1.4 (login endpoint)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 2.3.2: Create API Client with JWT Interceptors**
- **User Story:** As frontend developer, I want axios interceptors so JWT tokens are automatically sent with every request.
- **Acceptance Criteria:**
  - [ ] Axios client created
  - [ ] Request interceptor adds Authorization header
  - [ ] Response interceptor handles 401 (token refresh)
  - [ ] Automatic token refresh on expiration
  - [ ] Failed refresh redirects to login
  - [ ] Error handling for network failures
  - [ ] Tests verify interceptor logic
- **Dependencies:** Story 2.3.1
- **Blockers:** Story 2.1.3 (JWT configured)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 2.3.3: Create Login Page**
- **User Story:** As staff member, I want to log in so I can access patient records.
- **Acceptance Criteria:**
  - [ ] Page at `/login` with username + password form
  - [ ] Styled with Tailwind CSS
  - [ ] Submit button calls `authStore.login()`
  - [ ] Shows loading state during request
  - [ ] Shows error message if login fails
  - [ ] Redirects to `/dashboard` on success
  - [ ] Username field has focus on page load
  - [ ] Remember username option (optional, for later)
  - [ ] Tests verify form submission
- **Dependencies:** Story 2.3.1, Story 2.3.2
- **Blockers:** Story 2.1.4 (login endpoint)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 2.3.4: Create Protected Route Component**
- **User Story:** As frontend developer, I want protected routes so only authenticated users can access certain pages.
- **Acceptance Criteria:**
  - [ ] `ProtectedRoute` component checks `isAuthenticated` from auth store
  - [ ] Redirects to `/login` if not authenticated
  - [ ] Allows access if authenticated
  - [ ] Works with React Router v6
  - [ ] Tests verify redirect logic
- **Dependencies:** Story 2.3.1
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 3

---

**Story 2.3.5: Update App Router with Protected Routes**
- **User Story:** As frontend developer, I want the main App router configured so pages are properly protected.
- **Acceptance Criteria:**
  - [ ] `/login` route is public
  - [ ] All other routes are protected
  - [ ] `/dashboard` redirects to `/login` if not authenticated
  - [ ] Logout redirects to `/login`
  - [ ] Tests verify routing logic
- **Dependencies:** Story 2.3.4
- **Blockers:** Story 2.1.4, Story 2.1.5
- **Assigned to:** [Frontend Lead]
- **Story Points:** 3

---

### Sprint 2 Summary

| Story | Title | Points | Assigned | Status |
|-------|-------|--------|----------|--------|
| 2.1.1 | Custom User Model | 5 | [Backend] | - |
| 2.1.2 | Roles & Permissions | 8 | [Backend] | - |
| 2.1.3 | JWT Configuration | 5 | [Backend] | - |
| 2.1.4 | Login Endpoint | 5 | [Backend] | - |
| 2.1.5 | Logout Endpoint | 5 | [Backend] | - |
| 2.1.6 | Current User Endpoint | 3 | [Backend] | - |
| 2.2.1 | Permission Classes | 8 | [Backend] | - |
| 2.2.2 | Role-Based Access | 5 | [Backend] | - |
| 2.2.3 | Audit Middleware | 5 | [Backend] | - |
| 2.3.1 | Auth Zustand Store | 5 | [Frontend] | - |
| 2.3.2 | JWT Interceptors | 5 | [Frontend] | - |
| 2.3.3 | Login Page | 5 | [Frontend] | - |
| 2.3.4 | Protected Routes | 3 | [Frontend] | - |
| 2.3.5 | Router Configuration | 3 | [Frontend] | - |

**Total Sprint 2: 55 story points**

---

## SPRINT 3: PATIENT MANAGEMENT
**Duration:** 1-2 weeks | **Estimate:** 40-50 story points

### Epic 3.1: Backend Patient Operations

**Story 3.1.1: Create Patient Model with Auto-Numbering**
- **User Story:** As system architect, I want patients to have human-readable IDs so staff can reference them easily.
- **Acceptance Criteria:**
  - [ ] Patient model created per Section 09
  - [ ] Auto-generated patient_number: MAC-PAT-000001, MAC-PAT-000002, etc.
  - [ ] UUID primary key (immutable)
  - [ ] All required fields: first_name, last_name, DOB, sex, phone, address, next_of_kin
  - [ ] Soft delete: is_active boolean (don't physically delete)
  - [ ] Versioning field for sync conflict detection
  - [ ] Timestamps: created_at, updated_at
  - [ ] Database indexes on phone_number, last_name, first_name
  - [ ] Django admin interface works
  - [ ] Tests verify uniqueness constraints
- **Dependencies:** Sprint 2 complete
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 8

---

**Story 3.1.2: Create Patient Serializers**
- **User Story:** As backend developer, I want serializers so I can validate and format patient data for API responses.
- **Acceptance Criteria:**
  - [ ] `PatientSerializer` for list/create views
  - [ ] `PatientDetailSerializer` for detail view (includes more fields)
  - [ ] Read-only fields: id, patient_number, created_at, created_by
  - [ ] Calculated field: age (from DOB)
  - [ ] Validation: birth date cannot be in future
  - [ ] Validation: phone number format
  - [ ] Tests verify validation logic
- **Dependencies:** Story 3.1.1
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 3.1.3: Create Patient ViewSet with CRUD**
- **User Story:** As frontend developer, I want patient CRUD endpoints so I can manage patient records.
- **Acceptance Criteria:**
  - [ ] POST `/api/v1/patients/` creates new patient
  - [ ] GET `/api/v1/patients/` lists all active patients (paginated, 20 per page)
  - [ ] GET `/api/v1/patients/{id}/` shows patient detail
  - [ ] PATCH `/api/v1/patients/{id}/` updates patient
  - [ ] DELETE `/api/v1/patients/{id}/` soft-deletes (sets is_active=False)
  - [ ] Only ADMIN/CLINICIAN can create/update
  - [ ] All authenticated users can view
  - [ ] Audit logs created for create/update/delete
  - [ ] Integration tests for all operations
- **Dependencies:** Story 3.1.2
- **Blockers:** None
- **Assigned to:** [Backend Lead]
- **Story Points:** 8

---

**Story 3.1.4: Create Patient Search Endpoint**
- **User Story:** As staff member, I want to search patients by name or phone so I can find existing records quickly.
- **Acceptance Criteria:**
  - [ ] GET `/api/v1/patients/search/?q=query` searches 4 fields:
    - patient_number, first_name, last_name, phone_number
  - [ ] Returns top 20 results (limited for performance)
  - [ ] Case-insensitive search
  - [ ] Uses indexed fields for performance
  - [ ] Empty query returns 400
  - [ ] Tests verify search accuracy
- **Dependencies:** Story 3.1.3
- **Blockers:** Database indexes (Section 09)
- **Assigned to:** [Backend Lead]
- **Story Points:** 5

---

**Story 3.1.5: Create Patient History Endpoint**
- **User Story:** As clinician, I want to see a patient's visit history so I understand their clinical background.
- **Acceptance Criteria:**
  - [ ] GET `/api/v1/patients/{id}/history/` returns all visits
  - [ ] Ordered by visit_date DESC (newest first)
  - [ ] Includes: visit_date, chief_complaint, diagnosis, treatment
  - [ ] Paginated (20 per page)
  - [ ] Only authenticated users can access
  - [ ] Tests verify ordering and pagination
- **Dependencies:** Story 3.1.3, Story 4.1 (visits model)
- **Blockers:** Visit model exists
- **Assigned to:** [Backend Lead]
- **Story Points:** 3

---

### Epic 3.2: Frontend Patient UI

**Story 3.2.1: Create Patient Service Layer**
- **User Story:** As frontend developer, I want a service layer so components don't call the API directly.
- **Acceptance Criteria:**
  - [ ] `patientService.list()` - fetch patients
  - [ ] `patientService.search(query)` - search by name/phone
  - [ ] `patientService.get(id)` - fetch patient detail
  - [ ] `patientService.create(data)` - register new patient
  - [ ] `patientService.update(id, data)` - update patient
  - [ ] `patientService.getHistory(id)` - fetch visit history
  - [ ] All methods use auth-configured axios client
  - [ ] Error handling for network failures
  - [ ] Tests verify API calls
- **Dependencies:** Sprint 2 complete (API client)
- **Blockers:** Story 3.1.3 (endpoints)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 3.2.2: Create Patient Zustand Store**
- **User Story:** As frontend developer, I want a patient store so components share patient state.
- **Acceptance Criteria:**
  - [ ] Store state: patients[], currentPatient, isLoading, error
  - [ ] `searchPatients(query)` method
  - [ ] `getPatient(id)` method
  - [ ] `registerPatient(data)` method
  - [ ] `updatePatient(id, data)` method
  - [ ] All methods set isLoading/error state
  - [ ] Tests verify state transitions
- **Dependencies:** Story 3.2.1
- **Blockers:** None
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 3.2.3: Create Patient Registration Form**
- **User Story:** As staff member, I want to register a new patient so I can create their record in the system.
- **Acceptance Criteria:**
  - [ ] Page at `/patients/register`
  - [ ] Form fields: first_name, last_name, DOB, sex, phone_number, address
  - [ ] Form validation (required fields highlighted)
  - [ ] Submit calls `patientStore.registerPatient()`
  - [ ] Success message shown on registration
  - [ ] Redirects to patient profile after success
  - [ ] Error message shown on failure
  - [ ] Loading state during submission
  - [ ] Tests verify form submission
- **Dependencies:** Story 3.2.2
- **Blockers:** Story 3.1.3 (endpoint)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 8

---

**Story 3.2.4: Create Patient Search Component**
- **User Story:** As staff member, I want to search for existing patients so I can access their records.
- **Acceptance Criteria:**
  - [ ] Component with search input + results list
  - [ ] Calls `patientStore.searchPatients()` on input
  - [ ] Shows loading spinner during search
  - [ ] Displays results: patient_number, name, phone, age
  - [ ] Clicking result navigates to patient profile
  - [ ] Handles empty results gracefully
  - [ ] Tests verify search behavior
- **Dependencies:** Story 3.2.2
- **Blockers:** Story 3.1.4 (endpoint)
- **Assigned to:** [Frontend Lead]
- **Story Points:** 5

---

**Story 3.2.5: Create Patient Profile Page**
- **User Story:** As clinician, I want to view a patient's complete profile so I have their medical context.
- **Acceptance Criteria:**
  - [ ] Page at `/patients/{id}`
  - [ ] Displays: patient_number, name, DOB, sex, phone, address, next_of_kin
  - [ ] Shows calculated age
  - [ ] Displays patient's visit history (last 5)
  - [ ] Button to record new visit
  - [ ] Button to view full history
  - [ ] Edit button (only for ADMIN/CLINICIAN)
  - [ ] Tests verify page layout
- **Dependencies:** Story 3.2.2, Story 3.1.5
- **Blockers:** Story 3.1.3
- **Assigned to:** [Frontend Lead]
- **Story Points:** 8

---

**Story 3.2.6: Create Patient List Page**
- **User Story:** As receptionist, I want to see a list of patients so I can find and manage records.
- **Acceptance Criteria:**
  - [ ] Page at `/patients`
  - [ ] Shows paginated list (20 per page)
  - [ ] Columns: patient_number, name, phone, sex, registered_date
  - [ ] Sorting by name, registration date
  - [ ] Filter by sex (optional)
  - [ ] Search box at top
  - [ ] Button to register new patient
  - [ ] Clicking row navigates to patient detail
  - [ ] Tests verify pagination and sorting
- **Dependencies:** Story 3.2.2, Story 3.2.5
- **Blockers:** Story 3.1.3
- **Assigned to:** [Frontend Lead]
- **Story Points:** 8

---

### Sprint 3 Summary

| Story | Title | Points | Assigned | Status |
|-------|-------|--------|----------|--------|
| 3.1.1 | Patient Model | 8 | [Backend] | - |
| 3.1.2 | Patient Serializers | 5 | [Backend] | - |
| 3.1.3 | Patient ViewSet | 8 | [Backend] | - |
| 3.1.4 | Patient Search | 5 | [Backend] | - |
| 3.1.5 | Patient History | 3 | [Backend] | - |
| 3.2.1 | Patient Service | 5 | [Frontend] | - |
| 3.2.2 | Patient Store | 5 | [Frontend] | - |
| 3.2.3 | Registration Form | 8 | [Frontend] | - |
| 3.2.4 | Search Component | 5 | [Frontend] | - |
| 3.2.5 | Profile Page | 8 | [Frontend] | - |
| 3.2.6 | Patient List Page | 8 | [Frontend] | - |

**Total Sprint 3: 68 story points**

---

## SPRINTS 4-8: SUMMARY & PATTERN

For brevity, Sprints 4-8 follow the same pattern as Sprints 1-3:

**Sprint 4: Clinical Visits & Vitals** (50 sp)
- Visit model, serializers, viewset
- Vitals model and endpoints
- Visit recording form
- Visit history display

**Sprint 5: Follow-up & Dashboard** (50 sp)
- Follow-up model and operations
- Dashboard metrics endpoints
- Follow-up filtering (today/overdue/upcoming)
- Dashboard UI with metrics

**Sprint 6: Offline-First System** (60 sp)
- IndexedDB schema and operations
- Sync engine implementation
- Conflict detection/resolution
- Network monitoring
- Push/pull sync endpoints

**Sprint 7: Audit, Security & Hardening** (55 sp)
- Audit log model and middleware
- Rate limiting
- Input validation
- CORS configuration
- Security headers

**Sprint 8: Testing & Deployment** (60 sp)
- Test coverage to >80%
- Production Docker builds
- Vercel deployment
- Render deployment
- Backup/recovery testing

---

## TASK ASSIGNMENT TEMPLATE

```markdown
# Task: [Story Number] - [Story Title]

**Assigned to:** [Developer Name]  
**Story Points:** [Number]  
**Sprint:** [Sprint Number]  
**Status:** Not Started  

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Blockers
- [List any blockers]

## Dependencies
- [List any dependencies]

## Completion Checklist
- [ ] Code written
- [ ] Unit tests written (>80% coverage)
- [ ] Code reviewed
- [ ] Merged to develop
- [ ] Verified in staging

## Notes
[Any additional context]
```

---

## TRACKING & METRICS

**Weekly Metrics to Track:**
- Sprint velocity (actual vs. planned)
- Test coverage percentage
- Bug count
- PR review time (should be <24 hours)
- Deployment frequency

**End of Sprint Review:**
- Demo completed stories
- Discuss blockers and learnings
- Adjust next sprint estimates if needed
- Update project roadmap

